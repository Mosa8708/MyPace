"use client"

import { useState } from "react"
import { useParams, useRouter } from "next/navigation"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { UserMenu } from "@/components/user-menu"
import { MobileNav } from "@/components/mobile-nav"
import { upcomingWorkouts } from "@/data/workouts"
import { ProtectedRoute } from "@/components/protected-route"
import {
  ArrowLeft,
  Clock,
  Dumbbell,
  Calendar,
  BarChart,
  CheckCircle,
  Timer,
  Play,
  Edit,
  Share2,
  Bookmark,
  AlertCircle,
} from "lucide-react"

export default function WorkoutDetailPage() {
  const params = useParams()
  const router = useRouter()
  const workoutId = params.id as string

  // Find the workout with the matching ID
  const workout = upcomingWorkouts.find((w) => w.id === workoutId)

  const [selectedExercise, setSelectedExercise] = useState(workout?.exercises[0]?.id || "")

  // If workout not found, redirect to dashboard
  if (!workout) {
    return (
      <ProtectedRoute>
        <div className="flex min-h-screen flex-col items-center justify-center">
          <div className="text-center">
            <AlertCircle className="mx-auto h-12 w-12 text-red-500 mb-4" />
            <h1 className="text-2xl font-bold mb-2">Workout Not Found</h1>
            <p className="text-muted-foreground mb-6">
              The workout you're looking for doesn't exist or has been removed.
            </p>
            <Link href="/dashboard">
              <Button>Return to Dashboard</Button>
            </Link>
          </div>
        </div>
      </ProtectedRoute>
    )
  }

  // Calculate total volume (weight × sets × reps)
  const totalVolume = workout.exercises.reduce((total, exercise) => {
    return total + (exercise.weight || 0) * exercise.sets * exercise.reps
  }, 0)

  // Get the selected exercise details
  const selectedExerciseDetails = workout.exercises.find((ex) => ex.id === selectedExercise)

  // Handle start workout
  const handleStartWorkout = () => {
    router.push(`/workout-session/${workout.id}`)
  }

  return (
    <ProtectedRoute>
      <div className="flex min-h-screen flex-col">
        <header className="sticky top-0 z-10 border-b bg-background">
          <div className="container flex h-16 items-center justify-between py-4">
            <div className="flex items-center gap-2">
              <Link href="/" className="flex items-center gap-2">
                <div className="bg-primary h-8 w-8 flex items-center justify-center rounded">
                  <span className="text-primary-foreground font-bold">MP</span>
                </div>
                <span className="font-bold text-xl">MyPace</span>
              </Link>
            </div>
            <nav className="hidden md:flex gap-6">
              <Link href="/dashboard" className="text-sm font-medium text-primary">
                Dashboard
              </Link>
              <Link href="/programs" className="text-sm font-medium text-muted-foreground hover:text-primary">
                Programs
              </Link>
              <Link href="/exercises" className="text-sm font-medium text-muted-foreground hover:text-primary">
                Exercises
              </Link>
              <Link href="/community" className="text-sm font-medium text-muted-foreground hover:text-primary">
                Community
              </Link>
            </nav>
            <div className="flex items-center gap-4">
              <div className="hidden md:block">
                <UserMenu />
              </div>
              <div className="md:hidden">
                <MobileNav />
              </div>
            </div>
          </div>
        </header>

        <main className="flex-1">
          {/* Workout Header */}
          <div className="bg-muted">
            <div className="container py-8">
              <Link
                href="/dashboard"
                className="inline-flex items-center text-sm mb-4 hover:text-primary transition-colors"
              >
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back to Dashboard
              </Link>

              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <Badge className="bg-primary">
                      {workout.category.charAt(0).toUpperCase() + workout.category.slice(1)}
                    </Badge>
                    <Badge variant="outline">
                      {workout.difficulty.charAt(0).toUpperCase() + workout.difficulty.slice(1)}
                    </Badge>
                  </div>
                  <h1 className="text-3xl font-bold mb-1">{workout.title}</h1>
                  <p className="text-muted-foreground">{workout.description}</p>
                </div>

                <div className="flex gap-3">
                  <Button
                    size="lg"
                    className="bg-primary text-white hover:bg-primary/90 hover:scale-[1.02] hover:shadow-md transition-all duration-300"
                    onClick={handleStartWorkout}
                  >
                    <Play className="mr-2 h-5 w-5" />
                    Start Workout
                  </Button>
                  <div className="flex gap-2">
                    <Button
                      size="icon"
                      variant="outline"
                      className="hover:bg-primary/10 hover:text-primary hover:scale-[1.02] hover:shadow-sm transition-all duration-300"
                    >
                      <Edit className="h-5 w-5" />
                    </Button>
                    <Button
                      size="icon"
                      variant="outline"
                      className="hover:bg-primary/10 hover:text-primary hover:scale-[1.02] hover:shadow-sm transition-all duration-300"
                    >
                      <Bookmark className="h-5 w-5" />
                    </Button>
                    <Button
                      size="icon"
                      variant="outline"
                      className="hover:bg-primary/10 hover:text-primary hover:scale-[1.02] hover:shadow-sm transition-all duration-300"
                    >
                      <Share2 className="h-5 w-5" />
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Workout Stats */}
          <div className="border-b">
            <div className="container py-4">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="flex items-center gap-3">
                  <Calendar className="h-5 w-5 text-primary" />
                  <div>
                    <p className="text-sm text-muted-foreground">Scheduled For</p>
                    <p className="font-medium">{workout.scheduledFor}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Clock className="h-5 w-5 text-primary" />
                  <div>
                    <p className="text-sm text-muted-foreground">Duration</p>
                    <p className="font-medium">{workout.duration} minutes</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Dumbbell className="h-5 w-5 text-primary" />
                  <div>
                    <p className="text-sm text-muted-foreground">Exercises</p>
                    <p className="font-medium">{workout.exercises.length} exercises</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <BarChart className="h-5 w-5 text-primary" />
                  <div>
                    <p className="text-sm text-muted-foreground">Total Volume</p>
                    <p className="font-medium">{totalVolume.toLocaleString()} kg</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Workout Content */}
          <div className="container py-8">
            <div className="grid md:grid-cols-3 gap-8">
              <div className="md:col-span-2">
                <Tabs defaultValue="exercises">
                  <TabsList className="mb-6">
                    <TabsTrigger value="exercises">Exercises</TabsTrigger>
                    <TabsTrigger value="notes">Notes</TabsTrigger>
                    <TabsTrigger value="history">History</TabsTrigger>
                  </TabsList>

                  <TabsContent value="exercises" className="space-y-6">
                    <div className="space-y-4">
                      {workout.exercises.map((exercise, index) => (
                        <Card
                          key={exercise.id}
                          className={`overflow-hidden transition-all duration-200 ${selectedExercise === exercise.id ? "ring-2 ring-primary" : ""}`}
                          onClick={() => setSelectedExercise(exercise.id)}
                        >
                          <CardContent className="p-0">
                            <div className="flex items-center">
                              <div className="relative h-16 w-16 md:h-24 md:w-24 flex-shrink-0">
                                <Image
                                  src={`/images/exercise-${exercise.name.toLowerCase().replace(/\s+/g, "-")}.jpg`}
                                  alt={exercise.name}
                                  fill
                                  className="object-cover"
                                  onError={(e) => {
                                    const target = e.target as HTMLImageElement
                                    target.src = "/images/exercise-default.jpg"
                                  }}
                                />
                              </div>
                              <div className="p-4 flex-1">
                                <div className="flex items-center justify-between mb-1">
                                  <h3 className="font-medium">
                                    {index + 1}. {exercise.name}
                                  </h3>
                                  {exercise.completed && (
                                    <Badge variant="outline" className="text-green-500 border-green-500">
                                      <CheckCircle className="h-3 w-3 mr-1" /> Completed
                                    </Badge>
                                  )}
                                </div>
                                <div className="flex flex-wrap gap-x-4 gap-y-1 text-sm text-muted-foreground">
                                  <span>{exercise.sets} sets</span>
                                  <span>{exercise.reps} reps</span>
                                  {exercise.weight && <span>{exercise.weight} kg</span>}
                                  {exercise.restTime && (
                                    <span className="flex items-center">
                                      <Timer className="h-3 w-3 mr-1" /> {exercise.restTime}s rest
                                    </span>
                                  )}
                                </div>
                                {exercise.notes && (
                                  <p className="mt-2 text-sm text-muted-foreground italic">Note: {exercise.notes}</p>
                                )}
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </TabsContent>

                  <TabsContent value="notes">
                    <Card>
                      <CardHeader>
                        <CardTitle>Workout Notes</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-muted-foreground">
                          This workout is part of your {workout.programName} program. Focus on proper form and
                          progressive overload. Make sure to warm up properly before starting the workout.
                        </p>
                        <div className="mt-4">
                          <h4 className="font-medium mb-2">Tips for this workout:</h4>
                          <ul className="list-disc pl-5 space-y-1 text-muted-foreground">
                            <li>Stay hydrated throughout the workout</li>
                            <li>Focus on mind-muscle connection</li>
                            <li>Maintain proper form even as fatigue sets in</li>
                            <li>Track your progress to see improvements over time</li>
                          </ul>
                        </div>
                      </CardContent>
                    </Card>
                  </TabsContent>

                  <TabsContent value="history">
                    <Card>
                      <CardHeader>
                        <CardTitle>Workout History</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-4">
                          <div className="border-b pb-4">
                            <div className="flex justify-between items-center mb-2">
                              <h3 className="font-medium">Last week</h3>
                              <Badge variant="outline">Completed</Badge>
                            </div>
                            <div className="flex items-center gap-4 text-sm text-muted-foreground">
                              <span>Duration: 58 min</span>
                              <span>Volume: 3,240 kg</span>
                            </div>
                            <div className="mt-2">
                              <p className="text-sm font-medium mb-1">Progress:</p>
                              <Progress value={85} className="h-2" />
                            </div>
                          </div>

                          <div className="border-b pb-4">
                            <div className="flex justify-between items-center mb-2">
                              <h3 className="font-medium">Two weeks ago</h3>
                              <Badge variant="outline">Completed</Badge>
                            </div>
                            <div className="flex items-center gap-4 text-sm text-muted-foreground">
                              <span>Duration: 62 min</span>
                              <span>Volume: 3,120 kg</span>
                            </div>
                            <div className="mt-2">
                              <p className="text-sm font-medium mb-1">Progress:</p>
                              <Progress value={80} className="h-2" />
                            </div>
                          </div>

                          <div>
                            <div className="flex justify-between items-center mb-2">
                              <h3 className="font-medium">Three weeks ago</h3>
                              <Badge variant="outline">Completed</Badge>
                            </div>
                            <div className="flex items-center gap-4 text-sm text-muted-foreground">
                              <span>Duration: 65 min</span>
                              <span>Volume: 2,980 kg</span>
                            </div>
                            <div className="mt-2">
                              <p className="text-sm font-medium mb-1">Progress:</p>
                              <Progress value={75} className="h-2" />
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </TabsContent>
                </Tabs>
              </div>

              <div>
                {selectedExerciseDetails && (
                  <Card>
                    <CardHeader>
                      <CardTitle>Exercise Details</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="relative h-48 w-full rounded-md overflow-hidden">
                        <Image
                          src={`/images/exercise-${selectedExerciseDetails.name.toLowerCase().replace(/\s+/g, "-")}.jpg`}
                          alt={selectedExerciseDetails.name}
                          fill
                          className="object-cover"
                          onError={(e) => {
                            const target = e.target as HTMLImageElement
                            target.src = "/images/exercise-default.jpg"
                          }}
                        />
                      </div>

                      <div>
                        <h3 className="text-xl font-bold mb-2">{selectedExerciseDetails.name}</h3>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <p className="text-sm text-muted-foreground">Sets</p>
                            <p className="font-medium">{selectedExerciseDetails.sets}</p>
                          </div>
                          <div>
                            <p className="text-sm text-muted-foreground">Reps</p>
                            <p className="font-medium">{selectedExerciseDetails.reps}</p>
                          </div>
                          {selectedExerciseDetails.weight && (
                            <div>
                              <p className="text-sm text-muted-foreground">Weight</p>
                              <p className="font-medium">{selectedExerciseDetails.weight} kg</p>
                            </div>
                          )}
                          {selectedExerciseDetails.restTime && (
                            <div>
                              <p className="text-sm text-muted-foreground">Rest</p>
                              <p className="font-medium">{selectedExerciseDetails.restTime} seconds</p>
                            </div>
                          )}
                        </div>
                      </div>

                      {selectedExerciseDetails.notes && (
                        <div>
                          <h4 className="font-medium mb-1">Notes:</h4>
                          <p className="text-sm text-muted-foreground">{selectedExerciseDetails.notes}</p>
                        </div>
                      )}

                      <div className="pt-4 border-t">
                        <h4 className="font-medium mb-2">Previous Performance:</h4>
                        <div className="space-y-2">
                          <div className="flex justify-between text-sm">
                            <span className="text-muted-foreground">Last week:</span>
                            <span>
                              {selectedExerciseDetails.weight ? `${selectedExerciseDetails.weight - 2.5} kg` : "N/A"} ×{" "}
                              {selectedExerciseDetails.reps}
                            </span>
                          </div>
                          <div className="flex justify-between text-sm">
                            <span className="text-muted-foreground">Two weeks ago:</span>
                            <span>
                              {selectedExerciseDetails.weight ? `${selectedExerciseDetails.weight - 5} kg` : "N/A"} ×{" "}
                              {selectedExerciseDetails.reps}
                            </span>
                          </div>
                        </div>
                      </div>

                      <Button className="w-full">View Exercise Guide</Button>
                    </CardContent>
                  </Card>
                )}

                <div className="mt-6">
                  <h3 className="font-bold text-lg mb-4">Program Information</h3>
                  {workout.programId && workout.programName && (
                    <Link href={`/programs/${workout.programId}`}>
                      <Card className="hover:bg-muted/50 transition-colors">
                        <CardContent className="p-4">
                          <div className="flex items-center gap-4">
                            <div className="relative w-16 h-16 rounded-md overflow-hidden">
                              <Image
                                src={`/images/program-${workout.programName.toLowerCase().replace(/\s+/g, "-")}.jpg`}
                                alt={workout.programName}
                                fill
                                className="object-cover"
                                onError={(e) => {
                                  const target = e.target as HTMLImageElement
                                  target.src = "/images/program-default.jpg"
                                }}
                              />
                            </div>
                            <div>
                              <h4 className="font-medium">{workout.programName}</h4>
                              <p className="text-sm text-muted-foreground">View program details</p>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </Link>
                  )}
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    </ProtectedRoute>
  )
}

