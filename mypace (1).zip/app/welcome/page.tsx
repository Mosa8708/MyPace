"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { ProtectedRoute } from "@/components/protected-route"
import { useAuth } from "@/context/auth-context"
import { CheckCircle, ArrowRight } from "lucide-react"
import { GymEquipmentAnimation } from "@/components/gym-equipment-animation"

export default function WelcomePage() {
  const { user } = useAuth()
  const router = useRouter()

  // Redirect to dashboard after 5 seconds
  useEffect(() => {
    const timer = setTimeout(() => {
      router.push("/dashboard")
    }, 5000)

    return () => clearTimeout(timer)
  }, [router])

  return (
    <ProtectedRoute>
      <div className="min-h-screen flex flex-col">
        <header className="container mx-auto px-4 py-6">
          <Link href="/" className="flex items-center gap-2 w-fit">
            <div className="bg-primary h-10 w-10 flex items-center justify-center rounded">
              <span className="text-primary-foreground font-bold text-xl">MP</span>
            </div>
            <span className="font-bold text-2xl">MyPace</span>
          </Link>
        </header>

        <main className="flex-1 relative flex items-center justify-center">
          {/* Background with animation */}
          <div className="absolute inset-0 z-0">
            <Image
              src="https://v0.blob.com/pjtmy8OGJ.png"
              alt="Fitness background"
              fill
              className="object-cover opacity-10"
            />
            <GymEquipmentAnimation />
          </div>

          <div className="container mx-auto px-4 py-12 relative z-10 text-center">
            <div className="max-w-2xl mx-auto">
              <div className="bg-primary/10 rounded-full w-24 h-24 flex items-center justify-center mx-auto mb-6">
                <CheckCircle className="h-12 w-12 text-primary" />
              </div>

              <h1 className="text-4xl md:text-5xl font-bold mb-4">
                WELCOME TO MYPACE, {user?.fullName.toUpperCase()}!
              </h1>

              <p className="text-xl text-gray-700 mb-8">
                Your account has been successfully created. Your fitness journey begins now!
              </p>

              <div className="space-y-6 max-w-md mx-auto mb-8">
                <div className="flex items-start gap-4 text-left">
                  <div className="bg-primary p-2 rounded-full shrink-0 mt-1">
                    <CheckCircle className="h-5 w-5 text-white" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold">Personalized Programs</h3>
                    <p className="text-gray-600">Access over 60 free programs tailored for your fitness goals</p>
                  </div>
                </div>

                <div className="flex items-start gap-4 text-left">
                  <div className="bg-primary p-2 rounded-full shrink-0 mt-1">
                    <CheckCircle className="h-5 w-5 text-white" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold">Progress Tracking</h3>
                    <p className="text-gray-600">Monitor your workouts and visualize your improvements</p>
                  </div>
                </div>

                <div className="flex items-start gap-4 text-left">
                  <div className="bg-primary p-2 rounded-full shrink-0 mt-1">
                    <CheckCircle className="h-5 w-5 text-white" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold">Expert Guidance</h3>
                    <p className="text-gray-600">Learn proper form with HD video demonstrations</p>
                  </div>
                </div>
              </div>

              <p className="text-gray-500 mb-8">You will be redirected to your dashboard in a few seconds...</p>

              <Button size="lg" asChild>
                <Link href="/dashboard">
                  Go to Dashboard Now
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
              </Button>
            </div>
          </div>
        </main>
      </div>
    </ProtectedRoute>
  )
}

