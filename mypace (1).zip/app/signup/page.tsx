"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import * as z from "zod"
import { Eye, EyeOff, ArrowLeft } from "lucide-react"
import { GymEquipmentAnimation } from "@/components/gym-equipment-animation"
import { useToast } from "@/hooks/use-toast"
import { useAuth } from "@/context/auth-context"
import { CongratulationsPopup } from "@/components/congratulations-popup"

// Form validation schema
const signupSchema = z.object({
  fullName: z.string().min(2, {
    message: "Full name must be at least 2 characters.",
  }),
  email: z.string().email({
    message: "Please enter a valid email address.",
  }),
  password: z.string().min(6, {
    message: "Password must be at least 6 characters.",
  }),
})

type SignupFormValues = z.infer<typeof signupSchema>

export default function SignupPage() {
  const [showPassword, setShowPassword] = useState(false)
  const [showCongratulations, setShowCongratulations] = useState(false)
  const router = useRouter()
  const { toast } = useToast()
  const { signup } = useAuth()

  // Initialize form with react-hook-form
  const form = useForm<SignupFormValues>({
    resolver: zodResolver(signupSchema),
    defaultValues: {
      fullName: "",
      email: "",
      password: "",
    },
  })

  // Form submission handler
  async function onSubmit(data: SignupFormValues) {
    try {
      const success = await signup(data.fullName, data.email, data.password)

      if (success) {
        // Show congratulations popup
        setShowCongratulations(true)

        // Toast notification
        toast({
          title: "Account created successfully",
          description: "Welcome to MyPace!",
        })
      } else {
        toast({
          title: "Registration failed",
          description: "There was a problem creating your account. Please try again.",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Registration failed",
        description: "There was a problem creating your account. Please try again.",
        variant: "destructive",
      })
    }
  }

  // Handle popup close and redirect
  const handlePopupClose = () => {
    setShowCongratulations(false)
    router.push("/dashboard")
  }

  return (
    <div className="min-h-screen flex flex-col">
      <header className="container mx-auto px-4 py-6">
        <Link href="/" className="flex items-center gap-2 w-fit">
          <div className="bg-primary h-10 w-10 flex items-center justify-center rounded">
            <span className="text-primary-foreground font-bold text-xl">MP</span>
          </div>
          <span className="font-bold text-2xl">MyPace</span>
        </Link>
      </header>

      <main className="flex-1 relative">
        {/* Background with animation */}
        <div className="absolute inset-0 z-0">
          <Image
            src="/images/login-background.jpg"
            alt="Fitness background showing a modern gym with equipment"
            fill
            className="object-cover opacity-10"
          />
          <GymEquipmentAnimation />
        </div>

        <div className="container mx-auto px-4 py-12 relative z-10">
          <div className="max-w-md mx-auto">
            <Link href="/" className="inline-flex items-center text-sm mb-6 hover:text-primary transition-colors">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to home
            </Link>

            <Card className="border-2">
              <CardHeader>
                <CardTitle className="text-3xl">CREATE ACCOUNT</CardTitle>
                <CardDescription>Join MyPace and start your fitness journey</CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                    <FormField
                      control={form.control}
                      name="fullName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Full Name</FormLabel>
                          <FormControl>
                            <Input placeholder="John Doe" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email</FormLabel>
                          <FormControl>
                            <Input type="email" placeholder="john@example.com" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="password"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Password</FormLabel>
                          <FormControl>
                            <div className="relative">
                              <Input type={showPassword ? "text" : "password"} placeholder="••••••••" {...field} />
                              <button
                                type="button"
                                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700"
                                onClick={() => setShowPassword(!showPassword)}
                              >
                                {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                              </button>
                            </div>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <Button
                      type="submit"
                      disabled={form.formState.isSubmitting}
                      className="w-full text-lg py-6 bg-primary text-white hover:bg-primary/90 hover:scale-[1.02] hover:shadow-md transition-all duration-300 btn-glow"
                    >
                      {form.formState.isSubmitting ? (
                        <>
                          <span className="mr-2">Creating Account</span>
                          <div className="h-5 w-5 animate-spin rounded-full border-2 border-white border-t-transparent"></div>
                        </>
                      ) : (
                        "Sign Up"
                      )}
                    </Button>
                  </form>
                </Form>
              </CardContent>
              <CardFooter className="flex justify-center">
                <p className="text-sm text-gray-500">
                  Already have an account?{" "}
                  <Link href="/login" className="text-primary hover:underline">
                    Sign in
                  </Link>
                </p>
              </CardFooter>
            </Card>
          </div>
        </div>
      </main>

      {/* Congratulations Popup */}
      <CongratulationsPopup
        isOpen={showCongratulations}
        onClose={handlePopupClose}
        username={form.getValues().fullName || "User"}
      />
    </div>
  )
}

