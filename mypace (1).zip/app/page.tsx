"use client"
import { useState, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { AppStoreButton, GooglePlayButton } from "@/components/store-buttons"
import { CircularProgress } from "@/components/circular-progress"
import { GymEquipmentAnimation } from "@/components/gym-equipment-animation"
import { Flame, Award, CheckCircle, Play, ChevronRight } from "lucide-react"
import { UserMenu } from "@/components/user-menu"
import { MobileNav } from "@/components/mobile-nav"
import { ProgramModal } from "@/components/program-modal"

// Update the strengthBuilderProgram data to include all three phases
const strengthBuilderProgram = {
  phases: [
    {
      title: "Foundation Building",
      description: "Establish a solid base by focusing on compound movements with moderate volume and intensity.",
      weeks: "Weeks 1-4",
      days: [
        {
          title: "Day 1: Upper Body Strength",
          exercises: [
            { name: "Barbell Bench Press", sets: 4, reps: "6 reps" },
            { name: "Bent-Over Barbell Rows", sets: 4, reps: "6 reps" },
            { name: "Seated Dumbbell Shoulder Press", sets: 3, reps: "8 reps" },
            { name: "Pull-Ups or Lat Pulldowns", sets: 3, reps: "8 reps" },
            { name: "Tricep Dips", sets: 3, reps: "10 reps" },
            { name: "Barbell Bicep Curls", sets: 3, reps: "10 reps" },
          ],
        },
        {
          title: "Day 2: Lower Body Strength",
          exercises: [
            { name: "Barbell Back Squats", sets: 4, reps: "6 reps" },
            { name: "Romanian Deadlifts", sets: 3, reps: "8 reps" },
            { name: "Leg Press", sets: 3, reps: "10 reps" },
            { name: "Seated Calf Raises", sets: 4, reps: "12 reps" },
            { name: "Planks", sets: 3, reps: "30 seconds" },
          ],
        },
        {
          title: "Day 3: Rest or Active Recovery",
          exercises: [],
        },
        {
          title: "Day 4: Upper Body Hypertrophy",
          exercises: [
            { name: "Incline Dumbbell Press", sets: 3, reps: "8 reps" },
            { name: "One-Arm Dumbbell Rows", sets: 3, reps: "8 reps" },
            { name: "Lateral Raises", sets: 3, reps: "12 reps" },
            { name: "Face Pulls", sets: 3, reps: "12 reps" },
            { name: "Hammer Curls", sets: 3, reps: "10 reps" },
            { name: "Overhead Tricep Extensions", sets: 3, reps: "10 reps" },
          ],
        },
        {
          title: "Day 5: Lower Body Hypertrophy",
          exercises: [
            { name: "Front Squats", sets: 3, reps: "8 reps" },
            { name: "Leg Curls", sets: 3, reps: "10 reps" },
            { name: "Walking Lunges", sets: 3, reps: "12 reps per leg" },
            { name: "Standing Calf Raises", sets: 4, reps: "12 reps" },
            { name: "Leg Raises", sets: 3, reps: "12 reps" },
          ],
        },
        {
          title: "Day 6 & 7: Rest or Active Recovery",
          exercises: [],
        },
      ],
    },
    {
      title: "Strength Emphasis",
      description: "Increase strength by incorporating lower repetition ranges with heavier weights.",
      weeks: "Weeks 5-8",
      days: [
        {
          title: "Day 1: Upper Body Strength",
          exercises: [
            { name: "Flat Barbell Bench Press", sets: 5, reps: "5 reps" },
            { name: "Bent-Over Rows", sets: 5, reps: "5 reps" },
            { name: "Seated Dumbbell Shoulder Press", sets: 4, reps: "6 reps" },
            { name: "Pull-Ups", sets: 4, reps: "6 reps" },
            { name: "Tricep Dips", sets: 3, reps: "8 reps" },
            { name: "Barbell Bicep Curls", sets: 3, reps: "8 reps" },
          ],
        },
        {
          title: "Day 2: Lower Body Strength",
          exercises: [
            { name: "Barbell Back Squats", sets: 5, reps: "5 reps" },
            { name: "Romanian Deadlifts", sets: 4, reps: "6 reps" },
            { name: "Leg Press", sets: 4, reps: "8 reps" },
            { name: "Seated Calf Raises", sets: 4, reps: "10 reps" },
            { name: "Planks", sets: 3, reps: "45 seconds" },
          ],
        },
        {
          title: "Day 3: Rest or Active Recovery",
          exercises: [],
        },
        {
          title: "Day 4: Upper Body Hypertrophy",
          exercises: [
            { name: "Incline Dumbbell Press", sets: 4, reps: "6 reps" },
            { name: "One-Arm Dumbbell Rows", sets: 4, reps: "6 reps" },
            { name: "Lateral Raises", sets: 3, reps: "10 reps" },
            { name: "Face Pulls", sets: 3, reps: "10 reps" },
            { name: "Hammer Curls", sets: 3, reps: "8 reps" },
            { name: "Overhead Tricep Extensions", sets: 3, reps: "8 reps" },
          ],
        },
        {
          title: "Day 5: Lower Body Hypertrophy",
          exercises: [
            { name: "Front Squats", sets: 4, reps: "6 reps" },
            { name: "Leg Curls", sets: 4, reps: "8 reps" },
            { name: "Walking Lunges", sets: 3, reps: "10 reps per leg" },
            { name: "Standing Calf Raises", sets: 4, reps: "10 reps" },
            { name: "Leg Raises", sets: 3, reps: "10 reps" },
          ],
        },
        {
          title: "Day 6 & 7: Rest or Active Recovery",
          exercises: [],
        },
      ],
    },
    {
      title: "Hypertrophy Focus",
      description: "Maximize muscle growth through increased volume and moderate intensity.",
      weeks: "Weeks 9-12",
      days: [
        {
          title: "Day 1: Chest and Triceps",
          exercises: [
            { name: "Incline Barbell Bench Press", sets: 4, reps: "8 reps" },
            { name: "Flat Dumbbell Press", sets: 4, reps: "8 reps" },
            { name: "Chest Flyes", sets: 3, reps: "12 reps" },
            { name: "Tricep Dips", sets: 3, reps: "10 reps" },
            { name: "Overhead Tricep Extensions", sets: 3, reps: "12 reps" },
          ],
        },
        {
          title: "Day 2: Back and Biceps",
          exercises: [
            { name: "Deadlifts", sets: 4, reps: "6 reps" },
            { name: "Pull-Ups or Lat Pulldowns", sets: 4, reps: "8 reps" },
            { name: "Seated Cable Rows", sets: 3, reps: "10 reps" },
            { name: "Barbell Bicep Curls", sets: 3, reps: "12 reps" },
            { name: "Hammer Curls", sets: 3, reps: "12 reps" },
          ],
        },
        {
          title: "Day 3: Rest or Active Recovery",
          exercises: [],
        },
        {
          title: "Day 4: Legs and Shoulders",
          exercises: [
            { name: "Barbell Back Squats", sets: 4, reps: "8 reps" },
            { name: "Romanian Deadlifts", sets: 3, reps: "10 reps" },
            { name: "Leg Press", sets: 3, reps: "12 reps" },
            { name: "Seated Dumbbell Shoulder Press", sets: 4, reps: "8 reps" },
            { name: "Lateral Raises", sets: 3, reps: "12 reps" },
            { name: "Face Pulls", sets: 3, reps: "12 reps" },
          ],
        },
        {
          title: "Day 5: Arms and Abs",
          exercises: [
            { name: "Close-Grip Bench Press", sets: 4, reps: "8 reps" },
            { name: "EZ-Bar Curls", sets: 4, reps: "8 reps" },
            { name: "Skull Crushers", sets: 3, reps: "10 reps" },
            { name: "Concentration Curls", sets: 3, reps: "10 reps" },
            { name: "Hanging Leg Raises", sets: 3, reps: "12 reps" },
            { name: "Russian Twists", sets: 3, reps: "20 reps (10 per side)" },
          ],
        },
        {
          title: "Day 6 & 7: Rest or Active Recovery",
          exercises: [],
        },
      ],
    },
  ],
  additionalConsiderations: [
    {
      title: "Progressive Overload",
      description:
        "Gradually increase the weight or number of reps each week to continually challenge your muscles and promote growth.",
    },
    {
      title: "Rest Periods",
      description:
        "Rest for 60-90 seconds between sets during hypertrophy workouts and 2-3 minutes during strength-focused workouts.",
    },
    {
      title: "Nutrition",
      description: "Ensure you're consuming adequate protein and calories to support muscle growth and recovery.",
    },
    {
      title: "Recovery",
      description:
        "Incorporate stretching, foam rolling, and sufficient sleep to aid in muscle recovery and prevent injury.",
    },
  ],
}

// Add this hiitChallengeProgram data structure to your page.tsx file,
// right after the strengthBuilderProgram definition

const hiitChallengeProgram = {
  phases: [
    {
      title: "Foundation Building",
      description: "Introduce your body to HIIT workouts, focusing on form and building endurance.",
      weeks: "Weeks 1-2",
      days: [
        {
          title: "HIIT Workout Structure",
          exercises: [
            {
              name: "Work-to-Rest Ratio",
              sets: 0,
              reps: "1:4 (15 seconds work, 60 seconds rest)",
              note: "Focus on form",
            },
            { name: "Total Rounds", sets: 0, reps: "10 rounds" },
            { name: "Total Workout Time", sets: 0, reps: "Approximately 14 minutes" },
            { name: "Warm-Up (5 minutes)", sets: 0, reps: "Light cardio and dynamic stretches" },
            { name: "HIIT Circuit", sets: 0, reps: "Perform exercises below for the work period" },
            { name: "Cool-Down (5 minutes)", sets: 0, reps: "Gentle stretching and deep breathing" },
          ],
        },
        {
          title: "Sample Exercises (Choose 3-4 per workout)",
          exercises: [
            { name: "Jumping Jacks", sets: 0, reps: "15 seconds high intensity" },
            { name: "High Knees", sets: 0, reps: "15 seconds high intensity" },
            { name: "Burpees", sets: 0, reps: "15 seconds high intensity" },
            { name: "Mountain Climbers", sets: 0, reps: "15 seconds high intensity" },
            { name: "Squat Jumps", sets: 0, reps: "15 seconds high intensity" },
            { name: "Push-Ups", sets: 0, reps: "15 seconds high intensity" },
            { name: "Lunges", sets: 0, reps: "15 seconds high intensity" },
            { name: "Plank with Shoulder Taps", sets: 0, reps: "15 seconds high intensity" },
          ],
        },
      ],
    },
    {
      title: "Endurance Enhancement",
      description: "Increase the duration of high-intensity intervals to build stamina.",
      weeks: "Weeks 3-4",
      days: [
        {
          title: "HIIT Workout Structure",
          exercises: [
            {
              name: "Work-to-Rest Ratio",
              sets: 0,
              reps: "1:2 (30 seconds work, 60 seconds rest)",
              note: "Focus on endurance",
            },
            { name: "Total Rounds", sets: 0, reps: "10 rounds" },
            { name: "Total Workout Time", sets: 0, reps: "Approximately 17 minutes" },
            { name: "Warm-Up (5 minutes)", sets: 0, reps: "Light cardio and dynamic stretches" },
            { name: "HIIT Circuit", sets: 0, reps: "Perform exercises below for the work period" },
            { name: "Cool-Down (5 minutes)", sets: 0, reps: "Gentle stretching and deep breathing" },
          ],
        },
        {
          title: "Sample Exercises (Choose 3-4 per workout)",
          exercises: [
            { name: "Jumping Jacks", sets: 0, reps: "30 seconds high intensity" },
            { name: "High Knees", sets: 0, reps: "30 seconds high intensity" },
            { name: "Burpees", sets: 0, reps: "30 seconds high intensity" },
            { name: "Mountain Climbers", sets: 0, reps: "30 seconds high intensity" },
            { name: "Squat Jumps", sets: 0, reps: "30 seconds high intensity" },
            { name: "Push-Ups", sets: 0, reps: "30 seconds high intensity" },
            { name: "Lunges", sets: 0, reps: "30 seconds high intensity" },
            { name: "Plank with Shoulder Taps", sets: 0, reps: "30 seconds high intensity" },
          ],
        },
      ],
    },
    {
      title: "Intensity Amplification",
      description: "Elevate the intensity by balancing work and rest periods equally.",
      weeks: "Weeks 5-6",
      days: [
        {
          title: "HIIT Workout Structure",
          exercises: [
            {
              name: "Work-to-Rest Ratio",
              sets: 0,
              reps: "1:1 (30 seconds work, 30 seconds rest)",
              note: "Equal work and rest",
            },
            { name: "Total Rounds", sets: 0, reps: "11 rounds" },
            { name: "Total Workout Time", sets: 0, reps: "Approximately 18.5 minutes" },
            { name: "Warm-Up (5 minutes)", sets: 0, reps: "Light cardio and dynamic stretches" },
            { name: "HIIT Circuit", sets: 0, reps: "Perform exercises below for the work period" },
            { name: "Cool-Down (5 minutes)", sets: 0, reps: "Gentle stretching and deep breathing" },
          ],
        },
        {
          title: "Sample Exercises (Choose 3-4 per workout)",
          exercises: [
            { name: "Jumping Jacks", sets: 0, reps: "30 seconds high intensity" },
            { name: "High Knees", sets: 0, reps: "30 seconds high intensity" },
            { name: "Burpees", sets: 0, reps: "30 seconds high intensity" },
            { name: "Mountain Climbers", sets: 0, reps: "30 seconds high intensity" },
            { name: "Squat Jumps", sets: 0, reps: "30 seconds high intensity" },
            { name: "Push-Ups", sets: 0, reps: "30 seconds high intensity" },
            { name: "Lunges", sets: 0, reps: "30 seconds high intensity" },
            { name: "Plank with Shoulder Taps", sets: 0, reps: "30 seconds high intensity" },
          ],
        },
      ],
    },
    {
      title: "Peak Performance",
      description:
        "Challenge your limits by increasing the work-to-rest ratio, enhancing cardiovascular fitness and muscular endurance.",
      weeks: "Weeks 7-8",
      days: [
        {
          title: "HIIT Workout Structure",
          exercises: [
            {
              name: "Work-to-Rest Ratio",
              sets: 0,
              reps: "2:1 (30 seconds work, 15 seconds rest)",
              note: "Maximum intensity",
            },
            { name: "Total Rounds", sets: 0, reps: "25 rounds" },
            { name: "Total Workout Time", sets: 0, reps: "Approximately 20 minutes" },
            { name: "Warm-Up (5 minutes)", sets: 0, reps: "Light cardio and dynamic stretches" },
            { name: "HIIT Circuit", sets: 0, reps: "Perform exercises below for the work period" },
            { name: "Cool-Down (5 minutes)", sets: 0, reps: "Gentle stretching and deep breathing" },
          ],
        },
        {
          title: "Sample Exercises (Choose 3-4 per workout)",
          exercises: [
            { name: "Jumping Jacks", sets: 0, reps: "30 seconds high intensity" },
            { name: "High Knees", sets: 0, reps: "30 seconds high intensity" },
            { name: "Burpees", sets: 0, reps: "30 seconds high intensity" },
            { name: "Mountain Climbers", sets: 0, reps: "30 seconds high intensity" },
            { name: "Squat Jumps", sets: 0, reps: "30 seconds high intensity" },
            { name: "Push-Ups", sets: 0, reps: "30 seconds high intensity" },
            { name: "Lunges", sets: 0, reps: "30 seconds high intensity" },
            { name: "Plank with Shoulder Taps", sets: 0, reps: "30 seconds high intensity" },
          ],
        },
      ],
    },
  ],
  additionalConsiderations: [
    {
      title: "Form First",
      description:
        "Prioritize proper form to prevent injury. If you're new to any exercise, start slowly and focus on technique.",
    },
    {
      title: "Rest and Recovery",
      description: "Listen to your body. Incorporate rest days and active recovery as needed.",
    },
    {
      title: "Nutrition",
      description:
        "Support your workouts with balanced nutrition, staying hydrated, and ensuring adequate protein intake.",
    },
    {
      title: "Adaptability",
      description:
        "Modify exercises to match your fitness level. For example, perform push-ups on your knees if standard push-ups are challenging.",
    },
  ],
}

// Add this powerLiftingProgram data structure to your page.tsx file,
// right after the hiitChallengeProgram definition

const powerLiftingProgram = {
  phases: [
    {
      title: "Hypertrophy Phase",
      description: "Build muscle mass and improve work capacity with higher volume and moderate intensity.",
      weeks: "Weeks 1-4",
      days: [
        {
          title: "Training Frequency Overview",
          exercises: [
            { name: "Weekly Sessions", sets: 0, reps: "4 sessions per week" },
            { name: "Squat Frequency", sets: 0, reps: "3 times per week" },
            { name: "Bench Press Frequency", sets: 0, reps: "4 times per week" },
            { name: "Deadlift Frequency", sets: 0, reps: "3 times per week" },
            { name: "Methodology", sets: 0, reps: "Combination of %1RM and RPE to dictate training loads" },
          ],
        },
        {
          title: "Hypertrophy Phase Focus",
          exercises: [
            { name: "Volume", sets: 0, reps: "Higher volume (more sets and reps)" },
            { name: "Intensity", sets: 0, reps: "Moderate (65-75% of 1RM)" },
            { name: "Accessory Work", sets: 0, reps: "Emphasis on muscle groups involved in main lifts" },
            { name: "Recovery", sets: 0, reps: "Adequate between sessions to support volume" },
          ],
        },
        {
          title: "Sample Day 1: Squat & Bench Focus",
          exercises: [
            { name: "Squat", sets: 4, reps: "8 reps at 65-70% 1RM" },
            { name: "Bench Press", sets: 4, reps: "8 reps at 65-70% 1RM" },
            { name: "Barbell Rows", sets: 3, reps: "10 reps" },
            { name: "Leg Extensions", sets: 3, reps: "12 reps" },
            { name: "Tricep Extensions", sets: 3, reps: "12 reps" },
          ],
        },
        {
          title: "Sample Day 2: Deadlift & Bench Variation",
          exercises: [
            { name: "Deadlift", sets: 4, reps: "8 reps at 65-70% 1RM" },
            { name: "Incline Bench Press", sets: 4, reps: "8 reps" },
            { name: "Pull-ups/Lat Pulldowns", sets: 3, reps: "10 reps" },
            { name: "Romanian Deadlifts", sets: 3, reps: "10 reps" },
            { name: "Dumbbell Shoulder Press", sets: 3, reps: "12 reps" },
          ],
        },
      ],
    },
    {
      title: "Strength Phase",
      description:
        "Increase maximal strength in the squat, bench press, and deadlift with moderate volume and increased intensity.",
      weeks: "Weeks 5-8",
      days: [
        {
          title: "Strength Phase Focus",
          exercises: [
            { name: "Volume", sets: 0, reps: "Moderate (fewer sets and reps than hypertrophy phase)" },
            { name: "Intensity", sets: 0, reps: "Higher (75-85% of 1RM)" },
            { name: "Accessory Work", sets: 0, reps: "Target weaknesses identified during hypertrophy phase" },
            { name: "Recovery", sets: 0, reps: "Increased focus on recovery between heavier sessions" },
          ],
        },
        {
          title: "Sample Day 1: Squat & Bench Focus",
          exercises: [
            { name: "Squat", sets: 4, reps: "5 reps at 75-80% 1RM" },
            { name: "Bench Press", sets: 4, reps: "5 reps at 75-80% 1RM" },
            { name: "Barbell Rows", sets: 3, reps: "8 reps" },
            { name: "Leg Press", sets: 3, reps: "10 reps" },
            { name: "Close-Grip Bench Press", sets: 3, reps: "8 reps" },
          ],
        },
        {
          title: "Sample Day 2: Deadlift & Bench Variation",
          exercises: [
            { name: "Deadlift", sets: 4, reps: "5 reps at 75-80% 1RM" },
            { name: "Incline Bench Press", sets: 4, reps: "5 reps" },
            { name: "Weighted Pull-ups", sets: 3, reps: "8 reps" },
            { name: "Good Mornings", sets: 3, reps: "8 reps" },
            { name: "Dumbbell Lateral Raises", sets: 3, reps: "10 reps" },
          ],
        },
      ],
    },
    {
      title: "Peaking Phase",
      description:
        "Prepare the body for maximal lifting by refining technique and maximizing neuromuscular efficiency.",
      weeks: "Weeks 9-12",
      days: [
        {
          title: "Peaking Phase Focus",
          exercises: [
            { name: "Volume", sets: 0, reps: "Lower (fewer sets and reps)" },
            { name: "Intensity", sets: 0, reps: "High (85-95% of 1RM)" },
            { name: "Accessory Work", sets: 0, reps: "Minimal, focusing on recovery and mobility" },
            { name: "Technique", sets: 0, reps: "Emphasis on perfecting form for competition lifts" },
          ],
        },
        {
          title: "Sample Day 1: Squat & Bench Focus",
          exercises: [
            { name: "Squat", sets: 3, reps: "3 reps at 85-90% 1RM" },
            { name: "Bench Press", sets: 3, reps: "3 reps at 85-90% 1RM" },
            { name: "Barbell Rows", sets: 2, reps: "6 reps" },
            { name: "Single-Leg Extensions", sets: 2, reps: "8 reps per leg" },
            { name: "Tricep Extensions", sets: 2, reps: "10 reps" },
          ],
        },
        {
          title: "Sample Day 2: Deadlift & Bench Variation",
          exercises: [
            { name: "Deadlift", sets: 3, reps: "3 reps at 85-90% 1RM" },
            { name: "Bench Press (Paused)", sets: 3, reps: "3 reps" },
            { name: "Pull-ups", sets: 2, reps: "6 reps" },
            { name: "Romanian Deadlifts", sets: 2, reps: "6 reps" },
            { name: "Face Pulls", sets: 2, reps: "12 reps" },
          ],
        },
      ],
    },
    {
      title: "Taper and Competition Phase",
      description: "Allow the body to recover and supercompensate, leading to peak performance.",
      weeks: "Weeks 13-16",
      days: [
        {
          title: "Taper Phase Focus",
          exercises: [
            { name: "Volume", sets: 0, reps: "Significantly reduced" },
            { name: "Intensity", sets: 0, reps: "Maintained but with fewer heavy sessions" },
            { name: "Accessory Work", sets: 0, reps: "Minimal to none" },
            { name: "Recovery", sets: 0, reps: "Prioritized to allow for supercompensation" },
          ],
        },
        {
          title: "Sample Day 1: Competition Lift Practice",
          exercises: [
            { name: "Squat", sets: 2, reps: "2 reps at 90% 1RM" },
            { name: "Bench Press", sets: 2, reps: "2 reps at 90% 1RM" },
            { name: "Deadlift", sets: 1, reps: "1 rep at 90% 1RM" },
            { name: "Light Mobility Work", sets: 0, reps: "As needed" },
          ],
        },
        {
          title: "Week 16: Competition/Test Week",
          exercises: [
            { name: "Squat 1RM Attempt", sets: 1, reps: "1 rep at 100%+ 1RM" },
            { name: "Bench Press 1RM Attempt", sets: 1, reps: "1 rep at 100%+ 1RM" },
            { name: "Deadlift 1RM Attempt", sets: 1, reps: "1 rep at 100%+ 1RM" },
            { name: "Note", sets: 0, reps: "Follow competition rules for attempts and rest periods" },
          ],
        },
      ],
    },
  ],
  additionalConsiderations: [
    {
      title: "Technique",
      description: "Prioritize mastering proper form in all lifts to prevent injury and ensure optimal performance.",
    },
    {
      title: "Recovery",
      description: "Incorporate adequate rest, nutrition, and mobility work to support training demands.",
    },
    {
      title: "Customization",
      description:
        "While the program offers a structured path, adjust accessory work and intensity based on individual progress and feedback.",
    },
    {
      title: "Accessing the Program",
      description:
        "The Calgary Barbell 16-Week Program is available for free and can be accessed through the Calgary Barbell Website or Boostcamp App.",
    },
  ],
}

// Function to get appropriate stock image for each program type
const getStockImageForProgram = (programType: string): string => {
  // Specific program mappings with detailed workout-relevant images
  const programMappings: Record<string, string> = {
    "strength builder": "https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?q=80&w=1470&auto=format&fit=crop",
    "home hiit challenge":
      "https://images.unsplash.com/photo-1599058945522-28d584b6f0ff?q=80&w=1469&auto=format&fit=crop",
    "powerlifting fundamentals":
      "https://images.unsplash.com/photo-1534438327276-14e5300c3a48?q=80&w=1470&auto=format&fit=crop",
    "30 day transformation":
      "https://images.unsplash.com/photo-1549060279-7e168fcee0c2?q=80&w=1470&auto=format&fit=crop",
  }

  // Check for exact program match first (case insensitive)
  const lowerProgramType = programType.toLowerCase()
  if (programMappings[lowerProgramType]) {
    return programMappings[lowerProgramType]
  }

  // Category-based fallbacks
  if (lowerProgramType.includes("strength") || lowerProgramType.includes("muscle")) {
    return "https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?q=80&w=1470&auto=format&fit=crop"
  } else if (lowerProgramType.includes("hiit") || lowerProgramType.includes("cardio")) {
    return "https://images.unsplash.com/photo-1599058945522-28d584b6f0ff?q=80&w=1469&auto=format&fit=crop"
  } else if (lowerProgramType.includes("power") || lowerProgramType.includes("lift")) {
    return "https://images.unsplash.com/photo-1534438327276-14e5300c3a48?q=80&w=1470&auto=format&fit=crop"
  } else if (lowerProgramType.includes("home") || lowerProgramType.includes("bodyweight")) {
    return "https://images.unsplash.com/photo-1518611012118-696072aa579a?q=80&w=1470&auto=format&fit=crop"
  } else if (lowerProgramType.includes("mobility") || lowerProgramType.includes("flex")) {
    return "https://images.unsplash.com/photo-1552196563-55cd4e45efb3?q=80&w=1526&auto=format&fit=crop"
  }

  // Default image if no match found
  return "https://images.unsplash.com/photo-1517836357463-d25dfeac3438?q=80&w=1470&auto=format&fit=crop"
}

export default function Home() {
  const [activeModal, setActiveModal] = useState<string | null>(null)
  const [hasMounted, setHasMounted] = useState(false)

  useEffect(() => {
    setHasMounted(true)
  }, [])

  const openModal = (modalId: string) => {
    setActiveModal(modalId)
    // Prevent scrolling when modal is open
    document.body.style.overflow = "hidden"
  }

  const closeModal = () => {
    setActiveModal(null)
    // Re-enable scrolling
    document.body.style.overflow = "auto"
  }

  // Add this custom animation for the glowing effect
  const pulseAnimation = `
  @keyframes pulse-slow {
    0%, 100% {
      box-shadow: 0 0 15px rgba(249, 115, 22, 0.5);
    }
    50% {
      box-shadow: 0 0 25px rgba(249, 115, 22, 0.8);
    }
  }
  .animate-pulse-slow {
    animation: pulse-slow 2s infinite;
  }
  `

  // Add the animation to the document
  useEffect(() => {
    if (hasMounted) {
      const style = document.createElement("style")
      style.innerHTML = pulseAnimation
      document.head.appendChild(style)
      return () => {
        document.head.removeChild(style)
      }
    }
  }, [hasMounted])

  if (!hasMounted) {
    return null
  }

  return (
    <div className="flex flex-col min-h-screen">
      <header className="absolute top-0 left-0 right-0 z-10">
        <div className="container mx-auto px-4 py-6 flex justify-between items-center">
          <Link href="/" className="flex items-center gap-2 z-10">
            <div className="bg-primary h-10 w-10 flex items-center justify-center rounded">
              <span className="text-primary-foreground font-bold text-xl">MP</span>
            </div>
            <span className="font-bold text-2xl text-white">MyPace</span>
          </Link>
          <div className="flex items-center gap-6 z-10">
            <Link href="/programs" className="text-sm font-medium text-white hover:text-primary hidden md:block">
              Programs
            </Link>
            <Link href="/exercises" className="text-sm font-medium text-white hover:text-primary hidden md:block">
              Exercises
            </Link>
            <Link href="/about" className="text-sm font-medium text-white hover:text-primary hidden md:block">
              About
            </Link>
            <div className="hidden md:block">
              <UserMenu />
            </div>
            <div className="md:hidden">
              <MobileNav />
            </div>
          </div>
        </div>
      </header>

      <main className="flex-1">
        {/* Hero Section with Background Image */}
        <section className="relative min-h-screen flex items-center">
          {/* Background Image */}
          <div className="absolute inset-0 z-0">
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Gym.jpg-fcpRIp4oKh8KDUQh5wBc32sPM8135M.jpeg"
              alt="Modern gym interior with people working out"
              fill
              className="object-cover"
              priority
            />
            <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/60 to-black/40"></div>
          </div>

          {/* Animated Gym Equipment */}
          <GymEquipmentAnimation />

          <div className="container mx-auto px-4 py-20 md:py-32 flex flex-col md:flex-row items-center relative z-1">
            <div className="md:w-1/2 space-y-8 text-center md:text-left mb-12 md:mb-0">
              <h1 className="text-5xl md:text-7xl font-bold text-white leading-tight">
                TRANSFORM <span className="text-primary">YOUR BODY</span> AT YOUR OWN PACE
              </h1>
              <p className="text-xl md:text-2xl text-gray-300">
                Science-based workout programs that make regular training accessible, effective, and joyful
              </p>
              <div className="pt-4 flex flex-col sm:flex-row gap-4">
                <Button
                  size="lg"
                  className="bg-orange-500 text-white hover:bg-orange-600 hover:scale-[1.03] transition-all duration-300 relative overflow-hidden group shadow-[0_0_15px_rgba(249,115,22,0.5)] animate-pulse-slow"
                  asChild
                >
                  <Link href="/signup" className="relative z-10 flex items-center">
                    <span className="relative z-10">Start Your Journey</span>
                    <span className="absolute inset-0 bg-white/10 opacity-0 group-hover:opacity-100 transform group-hover:scale-[1.05] transition-all duration-300 rounded-md"></span>
                    <span className="absolute -inset-x-1 -bottom-1 h-[2px] bg-white/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></span>
                  </Link>
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  className="text-white border-white hover:bg-orange-500 hover:border-orange-500 hover:text-white hover:scale-[1.03] transition-all duration-300 relative overflow-hidden group shadow-[0_0_10px_rgba(255,255,255,0.3)] hover:shadow-[0_0_15px_rgba(249,115,22,0.5)]"
                >
                  <Link href="/programs" className="relative z-10 flex items-center">
                    <span className="relative z-10">Explore Programs</span>
                    <span className="absolute inset-0 bg-white/5 opacity-0 group-hover:opacity-100 transform group-hover:scale-[1.05] transition-all duration-300 rounded-md"></span>
                    <span className="absolute -inset-x-1 -bottom-1 h-[2px] bg-white/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></span>
                  </Link>
                </Button>
              </div>
              <div className="pt-8 flex gap-4 justify-center md:justify-start">
                <AppStoreButton />
                <GooglePlayButton />
              </div>
            </div>
            <div className="md:w-1/2 flex justify-center md:justify-end">
              <div className="relative">
                {/* Device Frame */}
                <div className="relative mx-auto border-[14px] border-black rounded-[2.5rem] h-[600px] w-[300px] shadow-xl bg-black overflow-hidden">
                  <div className="w-[148px] h-[18px] bg-black absolute top-0 left-1/2 transform -translate-x-1/2 rounded-b-[1rem] z-10"></div>
                  {/* App Screenshot */}
                  <div className="relative h-full w-full">
                    <Image
                      src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Gym3-4oCszIpw8nDv4M0OTNt6sHE753H5NR.png"
                      alt="Fitness app showing a muscular athlete doing pull-ups"
                      fill
                      className="object-cover"
                    />
                  </div>
                </div>
                {/* Glow effect behind the device */}
                <div className="absolute -inset-4 bg-primary/20 rounded-full blur-xl -z-10"></div>
              </div>
            </div>
          </div>

          {/* Scroll indicator */}
          <div className="absolute bottom-10 left-1/2 transform -translate-x-1/2 flex flex-col items-center text-white">
            <span className="text-sm mb-2">Scroll to discover</span>
            <div className="w-6 h-10 border-2 border-white rounded-full flex justify-center p-1">
              <div className="w-1 h-2 bg-white rounded-full animate-bounce"></div>
            </div>
          </div>
        </section>

        {/* Featured Programs Section */}
        <section className="py-20 bg-white">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16">
              <h2 className="text-4xl md:text-5xl font-bold mb-4">EXPERT-CRAFTED PROGRAMS</h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Access over 60 free programs tailored for bodybuilding, powerlifting, and home workouts
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {/* Program Card 1 */}
              <div className="rounded-lg overflow-hidden shadow-lg group image-zoom">
                <div className="relative h-64">
                  <Image
                    src={getStockImageForProgram("Strength Builder") || "/placeholder.svg"}
                    alt="Strength Builder Program showing a person performing barbell squats"
                    fill
                    className="object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent"></div>
                  <div className="absolute bottom-4 left-4 right-4">
                    <h3 className="text-2xl font-bold text-white">STRENGTH BUILDER</h3>
                    <p className="text-gray-300">by Dr. Eric Helms</p>
                  </div>
                </div>
                <div className="p-6 bg-white">
                  <div className="flex justify-between items-center mb-4">
                    <span className="text-sm text-gray-500">12 Weeks</span>
                    <span className="bg-primary/10 text-primary px-2 py-1 rounded text-sm font-medium">
                      Intermediate
                    </span>
                  </div>
                  <p className="text-gray-700 mb-4">
                    A comprehensive program designed to build strength and muscle mass with proven techniques.
                  </p>
                  <Button
                    className="w-full bg-primary text-white hover:bg-primary/90 hover:scale-[1.02] hover:shadow-md transition-all duration-300"
                    onClick={() => openModal("strength-builder")}
                  >
                    View Program
                  </Button>
                </div>
              </div>

              {/* Program Card 2 */}
              <div className="rounded-lg overflow-hidden shadow-lg group image-zoom">
                <div className="relative h-64">
                  <Image
                    src={getStockImageForProgram("Home HIIT Challenge") || "/placeholder.svg"}
                    alt="Home HIIT Challenge showing a person doing high-intensity interval training"
                    fill
                    className="object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent"></div>
                  <div className="absolute bottom-4 left-4 right-4">
                    <h3 className="text-2xl font-bold text-white">HOME HIIT CHALLENGE</h3>
                    <p className="text-gray-300">by Alberto Nuñez</p>
                  </div>
                </div>
                <div className="p-6 bg-white">
                  <div className="flex justify-between items-center mb-4">
                    <span className="text-sm text-gray-500">8 Weeks</span>
                    <span className="bg-primary/10 text-primary px-2 py-1 rounded text-sm font-medium">All Levels</span>
                  </div>
                  <p className="text-gray-700 mb-4">
                    High-intensity interval training you can do at home with minimal equipment.
                  </p>
                  <Button
                    className="w-full bg-primary text-white hover:bg-primary/90 hover:scale-[1.02] hover:shadow-md transition-all duration-300"
                    onClick={() => openModal("hiit-challenge")}
                  >
                    View Program
                  </Button>
                </div>
              </div>

              {/* Program Card 3 */}
              <div className="rounded-lg overflow-hidden shadow-lg group image-zoom">
                <div className="relative h-64">
                  <Image
                    src={getStockImageForProgram("Powerlifting Fundamentals") || "/placeholder.svg"}
                    alt="Powerlifting Fundamentals showing a person performing a deadlift"
                    fill
                    className="object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent"></div>
                  <div className="absolute bottom-4 left-4 right-4">
                    <h3 className="text-2xl font-bold text-white">POWERLIFTING FUNDAMENTALS</h3>
                    <p className="text-gray-300">by Bryce Lewis</p>
                  </div>
                </div>
                <div className="p-6 bg-white">
                  <div className="flex justify-between items-center mb-4">
                    <span className="text-sm text-gray-500">16 Weeks</span>
                    <span className="bg-primary/10 text-primary px-2 py-1 rounded text-sm font-medium">
                      Beginner to Advanced
                    </span>
                  </div>
                  <p className="text-gray-700 mb-4">
                    Master the squat, bench press, and deadlift with this focused program.
                  </p>
                  <Button
                    className="w-full bg-primary text-white hover:bg-primary/90 hover:scale-[1.02] hover:shadow-md transition-all duration-300"
                    onClick={() => openModal("powerlifting")}
                  >
                    View Program
                  </Button>
                </div>
              </div>
            </div>

            <div className="text-center mt-12">
              <Button
                variant="outline"
                size="lg"
                className="group hover:bg-primary/10 hover:text-primary hover:scale-[1.03] hover:shadow-md transition-all duration-300"
              >
                <span>View All Programs</span>
                <ChevronRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform text-gray-500 group-hover:text-primary" />
              </Button>
            </div>
          </div>
        </section>

        {/* Rest of the sections remain unchanged */}
        {/* ... */}

        {/* Personalized Workout Plan Section */}
        <section className="py-20 bg-gray-50">
          <div className="container mx-auto px-4">
            <div className="flex flex-col md:flex-row items-center gap-12">
              <div className="md:w-1/2 flex justify-center">
                <div className="relative">
                  <CircularProgress value={70} maxValue={100} label="CURRENT" metric="88 kg" />
                  <div className="absolute -top-4 -right-4 bg-primary text-white rounded-full w-16 h-16 flex items-center justify-center text-xl font-bold">
                    70%
                  </div>
                </div>
              </div>
              <div className="md:w-1/2 space-y-6">
                <h2 className="text-4xl md:text-5xl font-bold">PERSONALIZED WORKOUT PLAN</h2>
                <p className="text-xl text-gray-700">
                  In our database, there are more than 200 exercises for different parts of the body
                </p>
                <div className="space-y-6">
                  <div className="flex items-start gap-4">
                    <div className="bg-primary p-3 rounded-full shrink-0">
                      <Flame className="h-6 w-6 text-white" />
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold mb-1">Optimized Exercise Selection</h3>
                      <p className="text-lg text-gray-700">
                        We combine static and dynamic exercises to get the best result.
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start gap-4">
                    <div className="bg-primary p-3 rounded-full shrink-0">
                      <Award className="h-6 w-6 text-white" />
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold mb-1">Rapid Results</h3>
                      <p className="text-lg text-gray-700">
                        You will see first body changes after <strong>8 workouts</strong>.
                      </p>
                    </div>
                  </div>
                </div>
                {/* Find the "Create Your Plan" button in the Personalized Workout Plan section
                // and update it to use the Link component for navigation

                // Replace this button:
                <Button
                  size="lg"
                  className="mt-4 bg-primary text-white hover:bg-primary/90 hover:scale-[1.02] hover:shadow-md transition-all duration-300"
                >
                  Create Your Plan
                </Button>

                // With this button that includes the Link component: */}
                <Button
                  size="lg"
                  className="mt-4 bg-primary text-white hover:bg-primary/90 hover:scale-[1.02] hover:shadow-md transition-all duration-300"
                  asChild
                >
                  <Link href="/create-plan">Create Your Plan</Link>
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Features Section with Images */}
        <section className="py-20 bg-white">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16">
              <h2 className="text-4xl md:text-5xl font-bold mb-4">KEY FEATURES</h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Everything you need to achieve your fitness goals in one place
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              <div className="bg-white rounded-lg shadow-lg overflow-hidden group image-zoom">
                <div className="relative h-48">
                  <Image
                    src="/images/personalized-programs.jpg"
                    alt="Personalized Programs showing a fitness coach working with a client on a custom workout plan"
                    fill
                    className="object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                </div>
                <div className="p-6">
                  <h3 className="text-2xl font-bold mb-3">Personalized Programs</h3>
                  <p className="text-gray-700 mb-4">
                    Get a workout plan tailored to your fitness level, goals, and available equipment.
                  </p>
                  <ul className="space-y-2">
                    <li className="flex items-center">
                      <CheckCircle className="h-5 w-5 text-primary mr-2" />
                      <span>Adaptive difficulty progression</span>
                    </li>
                    <li className="flex items-center">
                      <CheckCircle className="h-5 w-5 text-primary mr-2" />
                      <span>Equipment-based alternatives</span>
                    </li>
                    <li className="flex items-center">
                      <CheckCircle className="h-5 w-5 text-primary mr-2" />
                      <span>Goal-specific training</span>
                    </li>
                  </ul>
                </div>
              </div>

              <div className="bg-white rounded-lg shadow-lg overflow-hidden group image-zoom">
                <div className="relative h-48">
                  <Image
                    src="/images/video-demonstrations.jpg"
                    alt="Video Demonstrations showing a fitness instructor demonstrating proper exercise form"
                    fill
                    className="object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="bg-primary/80 rounded-full p-3">
                      <Play className="h-8 w-8 text-white" />
                    </div>
                  </div>
                </div>
                <div className="p-6">
                  <h3 className="text-2xl font-bold mb-3">Video Demonstrations</h3>
                  <p className="text-gray-700 mb-4">
                    Learn proper form with HD video demonstrations for every exercise in your routine.
                  </p>
                  <ul className="space-y-2">
                    <li className="flex items-center">
                      <CheckCircle className="h-5 w-5 text-primary mr-2" />
                      <span>Multiple angles for clarity</span>
                    </li>
                    <li className="flex items-center">
                      <CheckCircle className="h-5 w-5 text-primary mr-2" />
                      <span>Expert form guidance</span>
                    </li>
                    <li className="flex items-center">
                      <CheckCircle className="h-5 w-5 text-primary mr-2" />
                      <span>Slow-motion breakdowns</span>
                    </li>
                  </ul>
                </div>
              </div>

              <div className="bg-white rounded-lg shadow-lg overflow-hidden group image-zoom">
                <div className="relative h-48">
                  <Image
                    src="/images/progress-tracking.jpg"
                    alt="Progress Tracking showing a person reviewing their fitness data on a mobile app"
                    fill
                    className="object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                </div>
                <div className="p-6">
                  <h3 className="text-2xl font-bold mb-3">Progress Tracking</h3>
                  <p className="text-gray-700 mb-4">
                    Track your workouts, monitor your progress, and visualize your improvements over time.
                  </p>
                  <ul className="space-y-2">
                    <li className="flex items-center">
                      <CheckCircle className="h-5 w-5 text-primary mr-2" />
                      <span>Detailed performance metrics</span>
                    </li>
                    <li className="flex items-center">
                      <CheckCircle className="h-5 w-5 text-primary mr-2" />
                      <span>Visual progress charts</span>
                    </li>
                    <li className="flex items-center">
                      <CheckCircle className="h-5 w-5 text-primary mr-2" />
                      <span>Achievement milestones</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Testimonials Section */}
        <section className="py-20 bg-gray-900 text-white">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16">
              <h2 className="text-4xl md:text-5xl font-bold mb-4">SUCCESS STORIES</h2>
              <p className="text-xl text-gray-300 max-w-3xl mx-auto">
                See how MyPace has transformed the fitness journey of our users
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {/* Testimonial 1 */}
              <div className="bg-gray-800 p-6 rounded-lg">
                <div className="flex items-center mb-4">
                  <div className="relative w-16 h-16 rounded-full overflow-hidden mr-4">
                    <Image
                      src="/images/mas-testimonial.jpeg"
                      alt="Mas M., a user who lost 15kg in 3 months"
                      fill
                      className="object-cover"
                    />
                  </div>
                  <div>
                    <h3 className="font-bold text-xl">Mas M.</h3>
                    <p className="text-gray-400">Lost 15kg in 3 months</p>
                  </div>
                </div>
                <p className="text-gray-300">
                  "MyPace completely changed my approach to fitness. The structured programs and progress tracking kept
                  me motivated, and the results speak for themselves!"
                </p>
                <div className="flex mt-4">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <Star key={star} />
                  ))}
                </div>
              </div>

              {/* Testimonial 2 */}
              <div className="bg-gray-800 p-6 rounded-lg">
                <div className="flex items-center mb-4">
                  <div className="relative w-16 h-16 rounded-full overflow-hidden mr-4">
                    <Image
                      src="/images/mosa-testimonial.jpeg"
                      alt="Mosa R., a user who gained 8kg of muscle"
                      fill
                      className="object-cover"
                    />
                  </div>
                  <div>
                    <h3 className="font-bold text-xl">Mosa R.</h3>
                    <p className="text-gray-400">Gained 8kg of muscle</p>
                  </div>
                </div>
                <p className="text-gray-300">
                  "As someone who struggled with consistency, the video demonstrations and personalized programs made
                  all the difference. I've never been stronger!"
                </p>
                <div className="flex mt-4">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <Star key={star} />
                  ))}
                </div>
              </div>

              {/* Testimonial 3 */}
              <div className="bg-gray-800 p-6 rounded-lg">
                <div className="flex items-center mb-4">
                  <div className="relative w-16 h-16 rounded-full overflow-hidden mr-4">
                    <Image
                      src="/images/kelz-testimonial.jpeg"
                      alt="Kelz K., a user who improved strength by 40%"
                      fill
                      className="object-cover"
                    />
                  </div>
                  <div>
                    <h3 className="font-bold text-xl">Kelz K.</h3>
                    <p className="text-gray-400">Improved strength by 40%</p>
                  </div>
                </div>
                <p className="text-gray-300">
                  "The expert-crafted programs are incredible. I've tried many fitness apps, but MyPace's science-based
                  approach and community support are unmatched."
                </p>
                <div className="flex mt-4">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <Star key={star} />
                  ))}
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 bg-primary text-white">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-4xl md:text-5xl font-bold mb-6">READY TO TRANSFORM YOUR FITNESS JOURNEY?</h2>
            <p className="text-xl mb-8 max-w-2xl mx-auto">
              Join thousands of users who have already achieved their fitness goals with MyPace.
            </p>
            <Button
              size="xl"
              variant="cta"
              className="text-lg pulse-button btn-shimmer text-white font-semibold"
              asChild
            >
              <Link href="/signup">Sign Up Now</Link>
            </Button>
            <div className="mt-8 flex flex-wrap justify-center gap-8">
              <div className="flex items-center">
                <CheckCircle className="h-6 w-6 mr-2" />
                <span>No credit card required</span>
              </div>
              <div className="flex items-center">
                <CheckCircle className="h-6 w-6 mr-2" />
                <span>14-day free access</span>
              </div>
              <div className="flex items-center">
                <CheckCircle className="h-6 w-6 mr-2" />
                <span>Cancel anytime</span>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="bg-gray-900 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <Link href="/" className="flex items-center gap-2 mb-4">
                <div className="bg-primary h-10 w-10 flex items-center justify-center rounded">
                  <span className="text-primary-foreground font-bold text-xl">MP</span>
                </div>
                <span className="font-bold text-2xl">MyPace</span>
              </Link>
              <p className="text-gray-400">Making fitness accessible, effective, and enjoyable for everyone.</p>
            </div>
            <div>
              <h3 className="font-semibold text-xl mb-4">Features</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="#" className="text-gray-400 hover:text-white">
                    Workout Programs
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-gray-400 hover:text-white">
                    Exercise Library
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-gray-400 hover:text-white">
                    Progress Tracking
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-gray-400 hover:text-white">
                    Community
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold text-xl mb-4">Company</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="#" className="text-gray-400 hover:text-white">
                    About Us
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-gray-400 hover:text-white">
                    Careers
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-gray-400 hover:text-white">
                    Blog
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-gray-400 hover:text-white">
                    Contact
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold text-xl mb-4">Legal</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="#" className="text-gray-400 hover:text-white">
                    Terms of Service
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-gray-400 hover:text-white">
                    Privacy Policy
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-gray-400 hover:text-white">
                    Cookie Policy
                  </Link>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-12 pt-8 text-center text-gray-400">
            <p>© {new Date().getFullYear()} MyPace. All rights reserved.</p>
          </div>
        </div>
      </footer>

      {/* Program Modals */}
      <ProgramModal
        isOpen={activeModal === "strength-builder"}
        onClose={closeModal}
        title="STRENGTH BUILDER"
        author="Dr. Eric Helms"
        duration="12 Weeks"
        level="Intermediate"
        description="A well-structured 12-week gym program can effectively enhance both strength and muscle mass. This comprehensive plan is tailored for intermediate individuals, divided into three distinct phases to progressively challenge your muscles and promote growth. The program includes 4-5 workouts per week with a focus on strength and hypertrophy (muscle growth)."
        videoUrl="https://www.youtube.com/watch?v=qVek72z3F1U"
        phases={strengthBuilderProgram.phases}
        additionalConsiderations={strengthBuilderProgram.additionalConsiderations}
      />

      <ProgramModal
        isOpen={activeModal === "hiit-challenge"}
        onClose={closeModal}
        title="HOME HIIT CHALLENGE"
        author="Alberto Nuñez"
        duration="8 Weeks"
        level="All Levels"
        description="High-intensity interval training you can do at home with minimal equipment. This program is perfect for busy individuals looking to maximize results in minimal time, with workouts that can be completed in as little as 20 minutes."
        videoUrl="https://www.youtube.com/watch?v=edIK5SZYMZo"
        phases={hiitChallengeProgram.phases}
        additionalConsiderations={hiitChallengeProgram.additionalConsiderations}
      />

      <ProgramModal
        isOpen={activeModal === "powerlifting"}
        onClose={closeModal}
        title="POWERLIFTING FUNDAMENTALS"
        author="Bryce Lewis"
        duration="16 Weeks"
        level="Beginner to Advanced"
        description="Master the squat, bench press, and deadlift with this focused program. Based on the Calgary Barbell 16-Week Program, this structured approach will help you build raw strength and perfect your technique for the big three lifts through a combination of percentage-based and Rate of Perceived Exertion (RPE) training."
        videoUrl="https://www.youtube.com/watch?v=sNPljvt0SxI"
        phases={powerLiftingProgram.phases}
        additionalConsiderations={powerLiftingProgram.additionalConsiderations}
      />
    </div>
  )
}

function Star() {
  return (
    <svg className="w-5 h-5 text-yellow-500 fill-current" viewBox="0 0 24 24">
      <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" />
    </svg>
  )
}

