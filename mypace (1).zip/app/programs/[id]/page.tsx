"use client"

import { useState, useEffect } from "react"
import { useParams, useRouter } from "next/navigation"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { UserMenu } from "@/components/user-menu"
import { MobileNav } from "@/components/mobile-nav"
import { programs } from "@/data/programs"
import { ProgramModal } from "@/components/program-modal"
import {
  Clock,
  Dumbbell,
  Users,
  Star,
  Calendar,
  CheckCircle,
  ArrowLeft,
  Share2,
  Bookmark,
  ChevronDown,
  ChevronUp,
} from "lucide-react"

export default function ProgramDetailPage() {
  const params = useParams()
  const router = useRouter()
  const programId = params.id as string

  // Find the program with the matching ID
  const program = programs.find((p) => p.id === programId)

  // If program not found, redirect to programs page
  useEffect(() => {
    if (!program) {
      router.push("/programs")
    }
  }, [program, router])

  const [showFullDescription, setShowFullDescription] = useState(false)
  const [showProgramModal, setShowProgramModal] = useState(false)

  if (!program) {
    return null
  }

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-10 border-b bg-background">
        <div className="container flex h-16 items-center justify-between py-4">
          <div className="flex items-center gap-2">
            <Link href="/" className="flex items-center gap-2">
              <div className="bg-primary h-8 w-8 flex items-center justify-center rounded">
                <span className="text-primary-foreground font-bold">MP</span>
              </div>
              <span className="font-bold text-xl">MyPace</span>
            </Link>
          </div>
          <nav className="hidden md:flex gap-6">
            <Link href="/dashboard" className="text-sm font-medium text-muted-foreground hover:text-primary">
              Dashboard
            </Link>
            <Link href="/programs" className="text-sm font-medium text-primary">
              Programs
            </Link>
            <Link href="/exercises" className="text-sm font-medium text-muted-foreground hover:text-primary">
              Exercises
            </Link>
            <Link href="/community" className="text-sm font-medium text-muted-foreground hover:text-primary">
              Community
            </Link>
          </nav>
          <div className="flex items-center gap-4">
            <div className="hidden md:block">
              <UserMenu />
            </div>
            <div className="md:hidden">
              <MobileNav />
            </div>
          </div>
        </div>
      </header>

      <main className="flex-1">
        {/* Program Header */}
        <div className="relative">
          <div className="h-[300px] md:h-[400px] relative">
            <Image
              src={program.image || "/images/program-default.jpg"}
              alt={`${program.programTitle} program featuring ${program.level} level ${program.equipment} exercises`}
              fill
              className="object-cover"
              priority
              onError={(e) => {
                const target = e.target as HTMLImageElement
                target.src = "/images/program-default.jpg"
              }}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black via-black/60 to-transparent"></div>
          </div>

          <div className="container relative -mt-32 md:-mt-40 z-10 pb-8">
            <Link
              href="/programs"
              className="inline-flex items-center text-sm mb-4 text-white hover:text-primary transition-colors"
            >
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Programs
            </Link>

            <div className="flex flex-col md:flex-row md:items-end gap-6 md:gap-12">
              <div className="flex-1">
                <Badge className="mb-2 bg-primary">
                  {program.category.charAt(0).toUpperCase() + program.category.slice(1)}
                </Badge>
                <h1 className="text-3xl md:text-5xl font-bold text-white mb-2">{program.programTitle}</h1>
                <p className="text-xl text-gray-300">by {program.author}</p>
                <p className="text-sm text-gray-400">{program.authorTitle}</p>
              </div>

              <div className="flex flex-col sm:flex-row gap-3">
                <Button
                  size="lg"
                  className="bg-primary text-white hover:bg-primary/90 hover:scale-[1.02] hover:shadow-md transition-all duration-300"
                  onClick={() => setShowProgramModal(true)}
                >
                  Start Program
                </Button>
                <div className="flex gap-2">
                  <Button
                    size="lg"
                    variant="outline"
                    className="text-white border-white hover:bg-white/20 hover:text-white hover:scale-[1.02] hover:shadow-md transition-all duration-300"
                  >
                    <Bookmark className="mr-2 h-5 w-5" />
                    Save
                  </Button>
                  <Button
                    size="lg"
                    variant="outline"
                    className="text-white border-white hover:bg-white/20 hover:text-white hover:scale-[1.02] hover:shadow-md transition-all duration-300"
                  >
                    <Share2 className="mr-2 h-5 w-5" />
                    Share
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Program Stats */}
        <section className="py-8 bg-muted">
          <div className="container">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="flex flex-col items-center text-center p-4">
                <Clock className="h-8 w-8 text-primary mb-2" />
                <h3 className="font-bold">{program.duration}</h3>
                <p className="text-sm text-muted-foreground">Duration</p>
              </div>

              <div className="flex flex-col items-center text-center p-4">
                <Calendar className="h-8 w-8 text-primary mb-2" />
                <h3 className="font-bold">{program.trainingFrequency}</h3>
                <p className="text-sm text-muted-foreground">Frequency</p>
              </div>

              <div className="flex flex-col items-center text-center p-4">
                <Dumbbell className="h-8 w-8 text-primary mb-2" />
                <h3 className="font-bold">{program.keyLiftsFocus.join(", ")}</h3>
                <p className="text-sm text-muted-foreground">Key Focus</p>
              </div>

              <div className="flex flex-col items-center text-center p-4">
                <Users className="h-8 w-8 text-primary mb-2" />
                <h3 className="font-bold">{program.level}</h3>
                <p className="text-sm text-muted-foreground">Difficulty</p>
              </div>
            </div>
          </div>
        </section>

        {/* Program Content */}
        <section className="py-12">
          <div className="container">
            <div className="grid md:grid-cols-3 gap-8">
              <div className="md:col-span-2">
                <Tabs defaultValue="overview">
                  <TabsList className="grid grid-cols-3 w-full">
                    <TabsTrigger value="overview">Overview</TabsTrigger>
                    <TabsTrigger value="phases">Program Phases</TabsTrigger>
                    <TabsTrigger value="reviews">Reviews</TabsTrigger>
                  </TabsList>

                  <TabsContent value="overview" className="mt-6 space-y-6">
                    <div>
                      <h2 className="text-2xl font-bold mb-4">Program Description</h2>
                      <div className={`text-muted-foreground ${showFullDescription ? "" : "line-clamp-4"}`}>
                        <p className="mb-4">{program.description}</p>
                      </div>
                      <Button
                        variant="ghost"
                        onClick={() => setShowFullDescription(!showFullDescription)}
                        className="mt-2 flex items-center hover:bg-primary/10 hover:text-primary hover:scale-[1.02] transition-all duration-300"
                      >
                        {showFullDescription ? (
                          <>
                            Show Less <ChevronUp className="ml-2 h-4 w-4" />
                          </>
                        ) : (
                          <>
                            Show More <ChevronDown className="ml-2 h-4 w-4" />
                          </>
                        )}
                      </Button>
                    </div>

                    <div>
                      <h2 className="text-2xl font-bold mb-4">Key Focus Areas</h2>
                      <ul className="space-y-2">
                        {program.keyLiftsFocus.map((focus, index) => (
                          <li key={index} className="flex items-center">
                            <CheckCircle className="h-5 w-5 text-primary mr-2" />
                            <span>{focus}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div>
                      <h2 className="text-2xl font-bold mb-4">About the Author</h2>
                      <div className="flex items-center gap-4">
                        <div className="relative w-16 h-16 rounded-full overflow-hidden">
                          <Image
                            src={`/images/author-${program.author.toLowerCase().replace(/\s+/g, "-")}.jpg`}
                            alt={program.author}
                            fill
                            className="object-cover"
                            onError={(e) => {
                              const target = e.target as HTMLImageElement
                              target.src = "/images/author-default.jpg"
                            }}
                          />
                        </div>
                        <div>
                          <h3 className="font-bold text-lg">{program.author}</h3>
                          <p className="text-muted-foreground">{program.authorTitle}</p>
                        </div>
                      </div>
                    </div>
                  </TabsContent>

                  <TabsContent value="phases" className="mt-6 space-y-6">
                    <h2 className="text-2xl font-bold mb-4">Program Phases</h2>
                    <div className="space-y-4">
                      {program.phases.map((phase, index) => (
                        <Card key={index}>
                          <CardContent className="p-6">
                            <div className="flex justify-between items-center mb-2">
                              <h3 className="font-bold text-lg">{phase}</h3>
                              <Badge>Phase {index + 1}</Badge>
                            </div>
                            <p className="text-muted-foreground mb-4">
                              {index === 0
                                ? "Establish a solid foundation and learn proper form"
                                : index === program.phases.length - 1
                                  ? "Peak performance and final progression"
                                  : "Build upon the foundation and increase intensity"}
                            </p>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => setShowProgramModal(true)}
                              className="hover:bg-primary/10 hover:text-primary hover:scale-[1.02] hover:shadow-sm transition-all duration-300"
                            >
                              View Detailed Workouts
                            </Button>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </TabsContent>

                  <TabsContent value="reviews" className="mt-6 space-y-6">
                    <div className="flex items-center justify-between">
                      <h2 className="text-2xl font-bold">User Reviews</h2>
                      <div className="flex items-center">
                        <div className="flex mr-2">
                          {[1, 2, 3, 4, 5].map((star) => (
                            <Star
                              key={star}
                              className={`h-5 w-5 ${star <= Math.round(program.rating) ? "text-yellow-500 fill-yellow-500" : "text-gray-300"}`}
                            />
                          ))}
                        </div>
                        <span className="font-bold">{program.rating}</span>
                        <span className="text-muted-foreground ml-1">({program.reviews} reviews)</span>
                      </div>
                    </div>

                    <div className="space-y-6">
                      {/* Sample reviews */}
                      <div className="border rounded-lg p-6">
                        <div className="flex items-center mb-4">
                          <div className="relative w-12 h-12 rounded-full overflow-hidden mr-4">
                            <Image
                              src="/images/mas-testimonial.jpeg"
                              alt="Mas M."
                              fill
                              className="object-cover"
                              onError={(e) => {
                                const target = e.target as HTMLImageElement
                                target.src = "/images/user-default.jpg"
                              }}
                            />
                          </div>
                          <div>
                            <h3 className="font-bold">Mas M.</h3>
                            <div className="flex">
                              {[...Array(5)].map((_, i) => (
                                <Star
                                  key={i}
                                  className={`h-4 w-4 ${i < 5 ? "text-yellow-500 fill-yellow-500" : "text-gray-300"}`}
                                />
                              ))}
                            </div>
                          </div>
                        </div>
                        <p className="text-muted-foreground">
                          "This program completely changed my approach to {program.keyLiftsFocus[0].toLowerCase()}. The
                          structured progression and detailed instructions kept me motivated, and the results speak for
                          themselves!"
                        </p>
                      </div>

                      <div className="border rounded-lg p-6">
                        <div className="flex items-center mb-4">
                          <div className="relative w-12 h-12 rounded-full overflow-hidden mr-4">
                            <Image
                              src="/images/mosa-testimonial.jpeg"
                              alt="Mosa R."
                              fill
                              className="object-cover"
                              onError={(e) => {
                                const target = e.target as HTMLImageElement
                                target.src = "/images/user-default.jpg"
                              }}
                            />
                          </div>
                          <div>
                            <h3 className="font-bold">Mosa R.</h3>
                            <div className="flex">
                              {[...Array(5)].map((_, i) => (
                                <Star
                                  key={i}
                                  className={`h-4 w-4 ${i < 4 ? "text-yellow-500 fill-yellow-500" : "text-gray-300"}`}
                                />
                              ))}
                            </div>
                          </div>
                        </div>
                        <p className="text-muted-foreground">
                          "Great program for anyone looking to improve their {program.category}. The phased approach
                          makes it easy to follow and see progress. Would recommend to others at my level."
                        </p>
                      </div>
                    </div>

                    <div className="text-center mt-8">
                      <Button
                        variant="outline"
                        className="hover:bg-primary/10 hover:text-primary hover:scale-[1.02] hover:shadow-md transition-all duration-300"
                      >
                        See All Reviews
                      </Button>
                    </div>
                  </TabsContent>
                </Tabs>
              </div>

              <div>
                <Card>
                  <CardContent className="p-6 space-y-6">
                    <div className="text-center">
                      <h3 className="text-2xl font-bold mb-2">Ready to Start?</h3>
                      <p className="text-muted-foreground mb-4">Begin your fitness journey with this program today.</p>
                      <Button
                        className="w-full bg-primary text-white hover:bg-primary/90 hover:scale-[1.02] hover:shadow-md transition-all duration-300"
                        size="lg"
                        onClick={() => setShowProgramModal(true)}
                      >
                        Start Program
                      </Button>
                    </div>

                    <div className="space-y-4">
                      <h4 className="font-bold">What's Included:</h4>
                      <ul className="space-y-2">
                        <li className="flex items-center">
                          <CheckCircle className="h-5 w-5 text-primary mr-2 shrink-0" />
                          <span>Detailed workout plans for {program.duration}</span>
                        </li>
                        <li className="flex items-center">
                          <CheckCircle className="h-5 w-5 text-primary mr-2 shrink-0" />
                          <span>Progressive overload framework</span>
                        </li>
                        <li className="flex items-center">
                          <CheckCircle className="h-5 w-5 text-primary mr-2 shrink-0" />
                          <span>Video demonstrations for all exercises</span>
                        </li>
                        <li className="flex items-center">
                          <CheckCircle className="h-5 w-5 text-primary mr-2 shrink-0" />
                          <span>Progress tracking tools</span>
                        </li>
                      </ul>
                    </div>

                    <div className="pt-4 border-t">
                      <h4 className="font-bold mb-2">Share This Program:</h4>
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          className="flex-1 hover:bg-primary/10 hover:text-primary hover:scale-[1.02] hover:shadow-sm transition-all duration-300"
                        >
                          <Share2 className="mr-2 h-4 w-4" />
                          Share
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          className="flex-1 hover:bg-primary/10 hover:text-primary hover:scale-[1.02] hover:shadow-sm transition-all duration-300"
                        >
                          <Bookmark className="mr-2 h-4 w-4" />
                          Save
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <div className="mt-6">
                  <h3 className="font-bold text-lg mb-4">Related Programs</h3>
                  <div className="space-y-4">
                    {programs
                      .filter((p) => p.id !== program.id && p.category === program.category)
                      .slice(0, 3)
                      .map((relatedProgram) => (
                        <Link href={`/programs/${relatedProgram.id}`} key={relatedProgram.id}>
                          <div className="flex gap-4 group">
                            <div className="relative w-20 h-20 rounded-md overflow-hidden">
                              <Image
                                src={relatedProgram.image || "/images/program-default.jpg"}
                                alt={relatedProgram.programTitle}
                                fill
                                className="object-cover group-hover:scale-105 transition-transform"
                                onError={(e) => {
                                  const target = e.target as HTMLImageElement
                                  target.src = "/images/program-default.jpg"
                                }}
                              />
                            </div>
                            <div>
                              <h4 className="font-medium group-hover:text-primary transition-colors">
                                {relatedProgram.programTitle}
                              </h4>
                              <p className="text-sm text-muted-foreground">
                                {relatedProgram.duration} • {relatedProgram.level}
                              </p>
                            </div>
                          </div>
                        </Link>
                      ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Program Modal */}
      {showProgramModal && (
        <ProgramModal
          isOpen={showProgramModal}
          onClose={() => setShowProgramModal(false)}
          title={program.programTitle}
          author={program.author}
          duration={program.duration}
          level={program.level}
          description={program.description}
          videoUrl="https://www.youtube.com/watch?v=qVek72z3F1U"
          phases={[]}
          additionalConsiderations={[]}
        />
      )}
    </div>
  )
}

