"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { ArrowLeft, Calendar, Clock, Dumbbell, Users, ChevronDown, ChevronUp, CheckCircle, Star } from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { UserMenu } from "@/components/user-menu"
import { MobileNav } from "@/components/mobile-nav"
import { AuthAwareButton } from "@/components/auth-aware-button"

export default function ThirtyDayTransformationPage() {
  const [expandedSections, setExpandedSections] = useState<Record<string, boolean>>({})

  const toggleSection = (section: string) => {
    setExpandedSections((prev) => ({
      ...prev,
      [section]: !prev[section],
    }))
  }

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-10 border-b bg-background">
        <div className="container flex h-16 items-center justify-between py-4">
          <div className="flex items-center gap-2">
            <Link href="/" className="flex items-center gap-2">
              <div className="bg-primary h-8 w-8 flex items-center justify-center rounded">
                <span className="text-primary-foreground font-bold">MP</span>
              </div>
              <span className="font-bold text-xl">MyPace</span>
            </Link>
          </div>
          <nav className="hidden md:flex gap-6">
            <Link href="/dashboard" className="text-sm font-medium text-muted-foreground hover:text-primary">
              Dashboard
            </Link>
            <Link href="/programs" className="text-sm font-medium text-primary">
              Programs
            </Link>
            <Link href="/exercises" className="text-sm font-medium text-muted-foreground hover:text-primary">
              Exercises
            </Link>
            <Link href="/community" className="text-sm font-medium text-muted-foreground hover:text-primary">
              Community
            </Link>
          </nav>
          <div className="flex items-center gap-4">
            <div className="hidden md:block">
              <UserMenu />
            </div>
            <div className="md:hidden">
              <MobileNav />
            </div>
          </div>
        </div>
      </header>

      <main className="flex-1">
        {/* Program Header */}
        <div className="relative">
          <div className="h-[300px] md:h-[400px] relative">
            <Image
              src="https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?q=80&w=1000&auto=format&fit=crop"
              alt="30-Day Total Body Transformation Program"
              fill
              className="object-cover"
              priority
              onError={(e) => {
                const target = e.target as HTMLImageElement
                target.src = "/images/program-default.jpg"
              }}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black via-black/60 to-transparent"></div>
          </div>

          <div className="container relative -mt-32 md:-mt-40 z-10 pb-8">
            <Link
              href="/programs"
              className="inline-flex items-center text-sm mb-4 text-white hover:text-primary transition-colors"
            >
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Programs
            </Link>

            <div className="flex flex-col md:flex-row md:items-end gap-6 md:gap-12">
              <div className="flex-1">
                <Badge className="mb-2 bg-primary">Featured Program</Badge>
                <h1 className="text-3xl md:text-5xl font-bold text-white mb-2">Transform Your Body in Just 30 Days</h1>
                <p className="text-xl text-gray-300">by Dr. Eric Helms</p>
                <p className="text-sm text-gray-400">PhD in Exercise Science</p>
              </div>

              <div className="flex flex-col sm:flex-row gap-3">
                <AuthAwareButton
                  size="lg"
                  className="bg-primary text-white hover:bg-primary/90 hover:scale-[1.02] hover:shadow-md transition-all duration-300"
                  onAuthenticatedClick={() => {
                    console.log("User enrolled in 30-day program")
                  }}
                  saveAction="enroll in this program"
                >
                  Start Program
                </AuthAwareButton>
              </div>
            </div>
          </div>
        </div>

        {/* Program Stats */}
        <section className="py-8 bg-muted">
          <div className="container">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="flex flex-col items-center text-center p-4">
                <Clock className="h-8 w-8 text-primary mb-2" />
                <h3 className="font-bold">30 Days</h3>
                <p className="text-sm text-muted-foreground">Duration</p>
              </div>

              <div className="flex flex-col items-center text-center p-4">
                <Calendar className="h-8 w-8 text-primary mb-2" />
                <h3 className="font-bold">5-6 Sessions/Week</h3>
                <p className="text-sm text-muted-foreground">Frequency</p>
              </div>

              <div className="flex flex-col items-center text-center p-4">
                <Dumbbell className="h-8 w-8 text-primary mb-2" />
                <h3 className="font-bold">Strength, HIIT, Core</h3>
                <p className="text-sm text-muted-foreground">Focus</p>
              </div>

              <div className="flex flex-col items-center text-center p-4">
                <Users className="h-8 w-8 text-primary mb-2" />
                <h3 className="font-bold">All Levels</h3>
                <p className="text-sm text-muted-foreground">Difficulty</p>
              </div>
            </div>
          </div>
        </section>

        {/* Program Content */}
        <section className="py-12">
          <div className="container">
            <div className="grid md:grid-cols-3 gap-8">
              <div className="md:col-span-2">
                <Tabs defaultValue="overview">
                  <TabsList className="grid grid-cols-4 w-full">
                    <TabsTrigger value="overview">Overview</TabsTrigger>
                    <TabsTrigger value="phase1">Phase 1</TabsTrigger>
                    <TabsTrigger value="phase2">Phase 2</TabsTrigger>
                    <TabsTrigger value="phase3">Phase 3</TabsTrigger>
                  </TabsList>

                  <TabsContent value="overview" className="mt-6 space-y-6">
                    <div>
                      <h2 className="text-2xl font-bold mb-4">Program Description</h2>
                      <p className="text-muted-foreground mb-4">
                        This comprehensive 30-day program combines strength training, HIIT cardio, and nutrition
                        guidance to help you achieve maximum results in minimal time. Perfect for those looking to
                        jumpstart their fitness journey, this program is suitable for all fitness levels from beginners
                        to advanced.
                      </p>
                      <p className="text-muted-foreground mb-4">
                        The program is structured into three progressive phases, each designed to build upon the
                        previous one. You'll start with foundational movements to establish proper form and consistency,
                        then gradually increase intensity and complexity as your fitness improves.
                      </p>
                      <p className="text-muted-foreground">
                        Each workout includes a proper warm-up, a focused training session combining strength and cardio
                        elements, and a cool-down period. The program also includes a nutrition guide to maximize your
                        results.
                      </p>
                    </div>

                    <div>
                      <h2 className="text-2xl font-bold mb-4">Program Structure</h2>
                      <div className="space-y-4">
                        <div className="border rounded-lg overflow-hidden">
                          <div
                            className="bg-gray-100 p-4 font-medium border-b flex justify-between items-center cursor-pointer"
                            onClick={() => toggleSection("phase1")}
                          >
                            <h3 className="text-lg">Phase 1: Foundation (Days 1-10)</h3>
                            {expandedSections["phase1"] ? (
                              <ChevronUp className="h-5 w-5" />
                            ) : (
                              <ChevronDown className="h-5 w-5" />
                            )}
                          </div>
                          {expandedSections["phase1"] && (
                            <div className="p-4">
                              <p className="mb-3">
                                Build endurance and establish consistency with bodyweight exercises and light strength
                                training.
                              </p>
                              <ul className="space-y-2 list-disc pl-5">
                                <li>Focus on proper form and technique</li>
                                <li>Establish workout routine and habits</li>
                                <li>Introduce basic nutrition principles</li>
                                <li>Gradually increase workout duration</li>
                              </ul>
                            </div>
                          )}
                        </div>

                        <div className="border rounded-lg overflow-hidden">
                          <div
                            className="bg-gray-100 p-4 font-medium border-b flex justify-between items-center cursor-pointer"
                            onClick={() => toggleSection("phase2")}
                          >
                            <h3 className="text-lg">Phase 2: Progressive Overload (Days 11-20)</h3>
                            {expandedSections["phase2"] ? (
                              <ChevronUp className="h-5 w-5" />
                            ) : (
                              <ChevronDown className="h-5 w-5" />
                            )}
                          </div>
                          {expandedSections["phase2"] && (
                            <div className="p-4">
                              <p className="mb-3">
                                Increase intensity, incorporating more resistance and dynamic movements.
                              </p>
                              <ul className="space-y-2 list-disc pl-5">
                                <li>Add resistance with dumbbells or household items</li>
                                <li>Introduce compound movements</li>
                                <li>Increase workout intensity with supersets</li>
                                <li>Focus on nutrient timing and macronutrients</li>
                              </ul>
                            </div>
                          )}
                        </div>

                        <div className="border rounded-lg overflow-hidden">
                          <div
                            className="bg-gray-100 p-4 font-medium border-b flex justify-between items-center cursor-pointer"
                            onClick={() => toggleSection("phase3")}
                          >
                            <h3 className="text-lg">Phase 3: Peak Performance (Days 21-30)</h3>
                            {expandedSections["phase3"] ? (
                              <ChevronUp className="h-5 w-5" />
                            ) : (
                              <ChevronDown className="h-5 w-5" />
                            )}
                          </div>
                          {expandedSections["phase3"] && (
                            <div className="p-4">
                              <p className="mb-3">
                                High-intensity, full-body training to maximize fat loss and muscle definition.
                              </p>
                              <ul className="space-y-2 list-disc pl-5">
                                <li>Incorporate HIIT and Tabata protocols</li>
                                <li>Challenge yourself with complex movement patterns</li>
                                <li>Focus on intensity and minimal rest periods</li>
                                <li>Fine-tune nutrition for optimal performance</li>
                              </ul>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>

                    <div>
                      <h2 className="text-2xl font-bold mb-4">Daily Workout Structure</h2>
                      <div className="space-y-4">
                        <div className="border rounded-lg p-4">
                          <h3 className="font-bold mb-2">Warm-Up (5 minutes)</h3>
                          <p className="text-muted-foreground">
                            Dynamic stretching and mobility drills to prepare your body for the workout.
                          </p>
                        </div>
                        <div className="border rounded-lg p-4">
                          <h3 className="font-bold mb-2">Main Workout (30-40 minutes)</h3>
                          <p className="text-muted-foreground">
                            Combination of strength training and HIIT circuits tailored to your fitness level.
                          </p>
                        </div>
                        <div className="border rounded-lg p-4">
                          <h3 className="font-bold mb-2">Cool-Down (5 minutes)</h3>
                          <p className="text-muted-foreground">
                            Static stretching and deep breathing to promote recovery and flexibility.
                          </p>
                        </div>
                      </div>
                    </div>

                    <div>
                      <h2 className="text-2xl font-bold mb-4">Nutrition Plan Highlights</h2>
                      <div className="space-y-3">
                        <div className="flex items-start">
                          <CheckCircle className="h-5 w-5 text-primary mr-2 mt-0.5" />
                          <div>
                            <h3 className="font-bold">Protein-Rich Meals</h3>
                            <p className="text-muted-foreground">
                              Essential for muscle recovery and growth. Aim for 1.6-2g per kg of bodyweight.
                            </p>
                          </div>
                        </div>
                        <div className="flex items-start">
                          <CheckCircle className="h-5 w-5 text-primary mr-2 mt-0.5" />
                          <div>
                            <h3 className="font-bold">Healthy Carbs & Fats</h3>
                            <p className="text-muted-foreground">
                              Provide energy for workouts and support hormone production.
                            </p>
                          </div>
                        </div>
                        <div className="flex items-start">
                          <CheckCircle className="h-5 w-5 text-primary mr-2 mt-0.5" />
                          <div>
                            <h3 className="font-bold">Hydration Focus</h3>
                            <p className="text-muted-foreground">
                              Drink at least 3L of water daily to support recovery and performance.
                            </p>
                          </div>
                        </div>
                        <div className="flex items-start">
                          <CheckCircle className="h-5 w-5 text-primary mr-2 mt-0.5" />
                          <div>
                            <h3 className="font-bold">Meal Timing</h3>
                            <p className="text-muted-foreground">
                              Strategically time your meals around workouts for optimal energy and recovery.
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </TabsContent>

                  <TabsContent value="phase1" className="mt-6 space-y-6">
                    <h2 className="text-2xl font-bold mb-4">Phase 1: Foundation (Days 1-10)</h2>
                    <p className="text-muted-foreground mb-6">
                      The Foundation phase focuses on building endurance, establishing proper form, and creating
                      consistent habits. These workouts are designed to be accessible while challenging you
                      appropriately.
                    </p>

                    <div className="space-y-6">
                      <div>
                        <h3 className="text-xl font-bold mb-3">Week 1 Workouts</h3>
                        <div className="grid gap-4 md:grid-cols-2">
                          <Card>
                            <CardContent className="p-4">
                              <h4 className="font-bold mb-2">Day 1: Full Body Basics</h4>
                              <ul className="space-y-2">
                                <li>• Bodyweight Squats: 3 sets x 12 reps</li>
                                <li>• Push-ups (modified if needed): 3 sets x 8 reps</li>
                                <li>• Glute Bridges: 3 sets x 15 reps</li>
                                <li>• Plank: 3 sets x 20 seconds</li>
                                <li>• Jumping Jacks: 3 sets x 30 seconds</li>
                              </ul>
                            </CardContent>
                          </Card>
                          <Card>
                            <CardContent className="p-4">
                              <h4 className="font-bold mb-2">Day 2: Cardio Focus</h4>
                              <ul className="space-y-2">
                                <li>• Jogging/Brisk Walking: 5 minutes</li>
                                <li>• High Knees: 30 seconds on, 30 seconds rest x 4</li>
                                <li>• Mountain Climbers: 30 seconds on, 30 seconds rest x 4</li>
                                <li>• Jumping Jacks: 30 seconds on, 30 seconds rest x 4</li>
                                <li>• Cool-down walk: 5 minutes</li>
                              </ul>
                            </CardContent>
                          </Card>
                          <Card>
                            <CardContent className="p-4">
                              <h4 className="font-bold mb-2">Day 3: Upper Body</h4>
                              <ul className="space-y-2">
                                <li>• Push-ups (modified if needed): 3 sets x 10 reps</li>
                                <li>• Tricep Dips (using chair): 3 sets x 8 reps</li>
                                <li>• Superman Hold: 3 sets x 20 seconds</li>
                                <li>• Arm Circles: 3 sets x 30 seconds</li>
                                <li>• Plank to Downward Dog: 3 sets x 8 reps</li>
                              </ul>
                            </CardContent>
                          </Card>
                          <Card>
                            <CardContent className="p-4">
                              <h4 className="font-bold mb-2">Day 4: Lower Body</h4>
                              <ul className="space-y-2">
                                <li>• Bodyweight Squats: 3 sets x 15 reps</li>
                                <li>• Reverse Lunges: 3 sets x 10 reps each leg</li>
                                <li>• Glute Bridges: 3 sets x 15 reps</li>
                                <li>• Calf Raises: 3 sets x 20 reps</li>
                                <li>• Wall Sit: 3 sets x 30 seconds</li>
                              </ul>
                            </CardContent>
                          </Card>
                          <Card>
                            <CardContent className="p-4">
                              <h4 className="font-bold mb-2">Day 5: Core Focus</h4>
                              <ul className="space-y-2">
                                <li>• Plank: 3 sets x 30 seconds</li>
                                <li>• Bicycle Crunches: 3 sets x 12 reps each side</li>
                                <li>• Russian Twists: 3 sets x 10 reps each side</li>
                                <li>• Bird Dog: 3 sets x 8 reps each side</li>
                                <li>• Leg Raises: 3 sets x 10 reps</li>
                              </ul>
                            </CardContent>
                          </Card>
                          <Card>
                            <CardContent className="p-4">
                              <h4 className="font-bold mb-2">Day 6: Active Recovery</h4>
                              <ul className="space-y-2">
                                <li>• Light walking: 20-30 minutes</li>
                                <li>• Full body stretching routine: 10-15 minutes</li>
                                <li>• Foam rolling (if available): 5-10 minutes</li>
                              </ul>
                            </CardContent>
                          </Card>
                        </div>
                      </div>

                      <div>
                        <h3 className="text-xl font-bold mb-3">Nutrition Focus for Phase 1</h3>
                        <div className="space-y-4">
                          <div className="border rounded-lg p-4">
                            <h4 className="font-bold mb-2">Establishing Healthy Habits</h4>
                            <ul className="space-y-2 list-disc pl-5">
                              <li>Focus on whole, unprocessed foods</li>
                              <li>Aim for 3 balanced meals plus 1-2 snacks daily</li>
                              <li>Drink at least 2.5-3L of water daily</li>
                              <li>Reduce processed foods, sugary drinks, and alcohol</li>
                            </ul>
                          </div>
                          <div className="border rounded-lg p-4">
                            <h4 className="font-bold mb-2">Sample Day Meal Plan</h4>
                            <ul className="space-y-3">
                              <li>
                                <span className="font-medium">Breakfast:</span> Veggie omelet with 2-3 eggs, spinach,
                                peppers, and a slice of whole grain toast
                              </li>
                              <li>
                                <span className="font-medium">Snack:</span> Greek yogurt with berries and a tablespoon
                                of honey
                              </li>
                              <li>
                                <span className="font-medium">Lunch:</span> Grilled chicken salad with mixed greens,
                                vegetables, and olive oil dressing
                              </li>
                              <li>
                                <span className="font-medium">Snack:</span> Apple with 1 tablespoon of almond butter
                              </li>
                              <li>
                                <span className="font-medium">Dinner:</span> Baked salmon with roasted vegetables and
                                quinoa
                              </li>
                            </ul>
                          </div>
                        </div>
                      </div>
                    </div>
                  </TabsContent>

                  <TabsContent value="phase2" className="mt-6 space-y-6">
                    <h2 className="text-2xl font-bold mb-4">Phase 2: Progressive Overload (Days 11-20)</h2>
                    <p className="text-muted-foreground mb-6">
                      In the Progressive Overload phase, we'll increase intensity by adding resistance, incorporating
                      more dynamic movements, and reducing rest periods. This phase builds on the foundation you
                      established in Phase 1.
                    </p>

                    <div className="space-y-6">
                      <div>
                        <h3 className="text-xl font-bold mb-3">Week 2 Workouts</h3>
                        <div className="grid gap-4 md:grid-cols-2">
                          <Card>
                            <CardContent className="p-4">
                              <h4 className="font-bold mb-2">Day 11: Full Body Strength</h4>
                              <ul className="space-y-2">
                                <li>• Goblet Squats (with dumbbell/water bottle): 3 sets x 12 reps</li>
                                <li>• Push-ups (standard or incline): 3 sets x 10 reps</li>
                                <li>• Dumbbell Rows: 3 sets x 12 reps each arm</li>
                                <li>• Glute Bridge with March: 3 sets x 10 reps each leg</li>
                                <li>• Plank with Shoulder Taps: 3 sets x 20 seconds</li>
                              </ul>
                            </CardContent>
                          </Card>
                          <Card>
                            <CardContent className="p-4">
                              <h4 className="font-bold mb-2">Day 12: HIIT Circuit</h4>
                              <p className="text-sm text-muted-foreground mb-2">Complete 4 rounds of:</p>
                              <ul className="space-y-2">
                                <li>• Jumping Jacks: 40 seconds work, 20 seconds rest</li>
                                <li>• Mountain Climbers: 40 seconds work, 20 seconds rest</li>
                                <li>• Squat Jumps: 40 seconds work, 20 seconds rest</li>
                                <li>• Push-ups: 40 seconds work, 20 seconds rest</li>
                                <li>• Rest 1 minute between rounds</li>
                              </ul>
                            </CardContent>
                          </Card>
                          <Card>
                            <CardContent className="p-4">
                              <h4 className="font-bold mb-2">Day 13: Upper Body Focus</h4>
                              <ul className="space-y-2">
                                <li>• Push-ups (various hand positions): 3 sets x 12 reps</li>
                                <li>• Dumbbell Shoulder Press: 3 sets x 10 reps</li>
                                <li>• Tricep Dips: 3 sets x 12 reps</li>
                                <li>• Bent-Over Rows: 3 sets x 12 reps</li>
                                <li>• Lateral Raises: 3 sets x 12 reps</li>
                              </ul>
                            </CardContent>
                          </Card>
                          <Card>
                            <CardContent className="p-4">
                              <h4 className="font-bold mb-2">Day 14: Lower Body Power</h4>
                              <ul className="space-y-2">
                                <li>• Walking Lunges: 3 sets x 12 steps each leg</li>
                                <li>• Sumo Squats: 3 sets x 15 reps</li>
                                <li>• Single-Leg Glute Bridges: 3 sets x 10 reps each leg</li>
                                <li>• Lateral Lunges: 3 sets x 10 reps each side</li>
                                <li>• Calf Raises with Hold: 3 sets x 15 reps (hold at top for 2 seconds)</li>
                              </ul>
                            </CardContent>
                          </Card>
                          <Card>
                            <CardContent className="p-4">
                              <h4 className="font-bold mb-2">Day 15: Core & Cardio</h4>
                              <ul className="space-y-2">
                                <li>• Plank Variations: 3 sets x 40 seconds</li>
                                <li>• Mountain Climbers: 3 sets x 30 seconds</li>
                                <li>• Russian Twists with Weight: 3 sets x 12 each side</li>
                                <li>• V-Ups: 3 sets x 10 reps</li>
                                <li>• Burpees: 3 sets x 10 reps</li>
                              </ul>
                            </CardContent>
                          </Card>
                        </div>
                      </div>

                      <div>
                        <h3 className="text-xl font-bold mb-3">Nutrition Focus for Phase 2</h3>
                        <div className="space-y-4">
                          <div className="border rounded-lg p-4">
                            <h4 className="font-bold mb-2">Nutrient Timing & Macronutrients</h4>
                            <ul className="space-y-2 list-disc pl-5">
                              <li>Increase protein intake to support muscle recovery (1.6-2g per kg bodyweight)</li>
                              <li>Time carbohydrates around workouts for optimal energy</li>
                              <li>Include healthy fats for hormone production and satiety</li>
                              <li>Focus on post-workout nutrition within 30-60 minutes</li>
                            </ul>
                          </div>
                          <div className="border rounded-lg p-4">
                            <h4 className="font-bold mb-2">Sample Pre & Post Workout Meals</h4>
                            <div className="space-y-3">
                              <div>
                                <h5 className="font-medium">Pre-Workout (1-2 hours before):</h5>
                                <ul className="list-disc pl-5">
                                  <li>Oatmeal with banana and a tablespoon of almond butter</li>
                                  <li>Whole grain toast with 2 eggs</li>
                                  <li>Greek yogurt with berries and honey</li>
                                </ul>
                              </div>
                              <div>
                                <h5 className="font-medium">Post-Workout (within 30-60 minutes):</h5>
                                <ul className="list-disc pl-5">
                                  <li>Protein shake with banana and almond milk</li>
                                  <li>Grilled chicken with sweet potato and vegetables</li>
                                  <li>Tuna wrap with whole grain tortilla and vegetables</li>
                                </ul>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </TabsContent>

                  <TabsContent value="phase3" className="mt-6 space-y-6">
                    <h2 className="text-2xl font-bold mb-4">Phase 3: Peak Performance (Days 21-30)</h2>
                    <p className="text-muted-foreground mb-6">
                      The Peak Performance phase brings everything together with high-intensity, full-body training to
                      maximize fat loss and muscle definition. This phase will challenge you to push your limits and
                      finish strong.
                    </p>

                    <div className="space-y-6">
                      <div>
                        <h3 className="text-xl font-bold mb-3">Week 3 Workouts</h3>
                        <div className="grid gap-4 md:grid-cols-2">
                          <Card>
                            <CardContent className="p-4">
                              <h4 className="font-bold mb-2">Day 21: Full Body HIIT</h4>
                              <p className="text-sm text-muted-foreground mb-2">Complete 5 rounds of:</p>
                              <ul className="space-y-2">
                                <li>• Burpees: 45 seconds work, 15 seconds rest</li>
                                <li>• Squat Jumps: 45 seconds work, 15 seconds rest</li>
                                <li>• Push-up to Renegade Row: 45 seconds work, 15 seconds rest</li>
                                <li>• Mountain Climbers: 45 seconds work, 15 seconds rest</li>
                                <li>• Rest 1 minute between rounds</li>
                              </ul>
                            </CardContent>
                          </Card>
                          <Card>
                            <CardContent className="p-4">
                              <h4 className="font-bold mb-2">Day 22: Strength Supersets</h4>
                              <p className="text-sm text-muted-foreground mb-2">
                                Perform exercises back-to-back with minimal rest:
                              </p>
                              <ul className="space-y-2">
                                <li>• Superset 1: Goblet Squats (12 reps) + Push-ups (12 reps) x 3 sets</li>
                                <li>
                                  • Superset 2: Reverse Lunges (10 each leg) + Dumbbell Rows (12 each arm) x 3 sets
                                </li>
                                <li>• Superset 3: Glute Bridges (15 reps) + Tricep Dips (12 reps) x 3 sets</li>
                                <li>• Superset 4: Plank (45 seconds) + Mountain Climbers (30 seconds) x 3 sets</li>
                              </ul>
                            </CardContent>
                          </Card>
                          <Card>
                            <CardContent className="p-4">
                              <h4 className="font-bold mb-2">Day 23: Tabata Training</h4>
                              <p className="text-sm text-muted-foreground mb-2">
                                8 rounds of 20 seconds work, 10 seconds rest for each exercise:
                              </p>
                              <ul className="space-y-2">
                                <li>• Jumping Jacks</li>
                                <li>• Push-ups</li>
                                <li>• Bodyweight Squats</li>
                                <li>• Mountain Climbers</li>
                                <li>• Rest 1 minute between exercises</li>
                              </ul>
                            </CardContent>
                          </Card>
                          <Card>
                            <CardContent className="p-4">
                              <h4 className="font-bold mb-2">Day 24: Compound Movement Focus</h4>
                              <ul className="space-y-2">
                                <li>• Squat to Press: 4 sets x 12 reps</li>
                                <li>• Lunge to Curl: 4 sets x 10 reps each leg</li>
                                <li>• Deadlift to Row: 4 sets x 12 reps</li>
                                <li>• Push-up to Side Plank: 4 sets x 8 reps each side</li>
                                <li>• Burpee to Tuck Jump: 4 sets x 8 reps</li>
                              </ul>
                            </CardContent>
                          </Card>
                          <Card>
                            <CardContent className="p-4">
                              <h4 className="font-bold mb-2">Day 25: Core Circuit</h4>
                              <p className="text-sm text-muted-foreground mb-2">Complete 4 rounds of:</p>
                              <ul className="space-y-2">
                                <li>• Plank with Shoulder Taps: 45 seconds</li>
                                <li>• Russian Twists: 45 seconds</li>
                                <li>• V-Ups: 45 seconds</li>
                                <li>• Side Plank: 30 seconds each side</li>
                                <li>• Mountain Climbers: 45 seconds</li>
                                <li>• Rest 45 seconds between rounds</li>
                              </ul>
                            </CardContent>
                          </Card>
                          <Card>
                            <CardContent className="p-4">
                              <h4 className="font-bold mb-2">Day 26: Active Recovery</h4>
                              <ul className="space-y-2">
                                <li>• Light cardio: 20-30 minutes (walking, cycling, or swimming)</li>
                                <li>• Full body mobility routine: 15 minutes</li>
                                <li>• Foam rolling: 10 minutes</li>
                                <li>• Stretching: 10 minutes</li>
                              </ul>
                            </CardContent>
                          </Card>
                        </div>
                      </div>

                      <div>
                        <h3 className="text-xl font-bold mb-3">Nutrition Focus for Phase 3</h3>
                        <div className="space-y-4">
                          <div className="border rounded-lg p-4">
                            <h4 className="font-bold mb-2">Fine-Tuning for Optimal Performance</h4>
                            <ul className="space-y-2 list-disc pl-5">
                              <li>Optimize meal timing around your workouts</li>
                              <li>Increase water intake to 3-4L daily</li>
                              <li>Focus on anti-inflammatory foods to support recovery</li>
                              <li>Consider carb cycling (higher carbs on intense workout days)</li>
                            </ul>
                          </div>
                          <div className="border rounded-lg p-4">
                            <h4 className="font-bold mb-2">Sample High-Intensity Day Meal Plan</h4>
                            <ul className="space-y-3">
                              <li>
                                <span className="font-medium">Breakfast:</span> Protein pancakes with banana and a
                                drizzle of honey
                              </li>
                              <li>
                                <span className="font-medium">Pre-Workout Snack:</span> Apple with 1 tablespoon of
                                almond butter
                              </li>
                              <li>
                                <span className="font-medium">Post-Workout:</span> Protein shake with banana and berries
                              </li>
                              <li>
                                <span className="font-medium">Lunch:</span> Grilled chicken with sweet potato and
                                steamed vegetables
                              </li>
                              <li>
                                <span className="font-medium">Snack:</span> Greek yogurt with berries and a sprinkle of
                                granola
                              </li>
                              <li>
                                <span className="font-medium">Dinner:</span> Baked salmon with quinoa and roasted
                                vegetables
                              </li>
                            </ul>
                          </div>
                        </div>
                      </div>
                    </div>
                  </TabsContent>
                </Tabs>
              </div>

              <div>
                <Card>
                  <CardContent className="p-6 space-y-6">
                    <div className="text-center">
                      <h3 className="text-2xl font-bold mb-2">Ready to Transform?</h3>
                      <p className="text-muted-foreground mb-4">Begin your 30-day transformation journey today.</p>
                      <AuthAwareButton
                        className="w-full bg-primary text-white hover:bg-primary/90 hover:scale-[1.02] hover:shadow-md transition-all duration-300"
                        size="lg"
                        onAuthenticatedClick={() => {
                          console.log("User enrolled in 30-day program")
                        }}
                        saveAction="enroll in this program"
                      >
                        Start Program
                      </AuthAwareButton>
                    </div>

                    <div className="space-y-4">
                      <h4 className="font-bold">What's Included:</h4>
                      <ul className="space-y-2">
                        <li className="flex items-center">
                          <CheckCircle className="h-5 w-5 text-primary mr-2 shrink-0" />
                          <span>30 days of structured workouts</span>
                        </li>
                        <li className="flex items-center">
                          <CheckCircle className="h-5 w-5 text-primary mr-2 shrink-0" />
                          <span>Comprehensive nutrition guide</span>
                        </li>
                        <li className="flex items-center">
                          <CheckCircle className="h-5 w-5 text-primary mr-2 shrink-0" />
                          <span>Progress tracking tools</span>
                        </li>
                        <li className="flex items-center">
                          <CheckCircle className="h-5 w-5 text-primary mr-2 shrink-0" />
                          <span>Exercise video demonstrations</span>
                        </li>
                        <li className="flex items-center">
                          <CheckCircle className="h-5 w-5 text-primary mr-2 shrink-0" />
                          <span>Daily motivation and tips</span>
                        </li>
                      </ul>
                    </div>

                    <div className="pt-4 border-t">
                      <h4 className="font-bold mb-2">Program Results:</h4>
                      <div className="space-y-3">
                        <div className="flex items-start">
                          <CheckCircle className="h-5 w-5 text-primary mr-2 mt-0.5" />
                          <div>
                            <h5 className="font-medium">Improved Strength & Endurance</h5>
                            <p className="text-sm text-muted-foreground">
                              Progressive workouts build functional fitness
                            </p>
                          </div>
                        </div>
                        <div className="flex items-start">
                          <CheckCircle className="h-5 w-5 text-primary mr-2 mt-0.5" />
                          <div>
                            <h5 className="font-medium">Fat Loss & Muscle Definition</h5>
                            <p className="text-sm text-muted-foreground">Combined approach targets body composition</p>
                          </div>
                        </div>
                        <div className="flex items-start">
                          <CheckCircle className="h-5 w-5 text-primary mr-2 mt-0.5" />
                          <div>
                            <h5 className="font-medium">Increased Energy & Vitality</h5>
                            <p className="text-sm text-muted-foreground">
                              Optimized nutrition fuels your active lifestyle
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <div className="mt-6">
                  <h3 className="font-bold text-lg mb-4">Testimonials</h3>
                  <div className="space-y-4">
                    <div className="border rounded-lg p-4">
                      <div className="flex items-center mb-3">
                        <div className="relative w-12 h-12 rounded-full overflow-hidden mr-3">
                          <Image
                            src="/images/mas-testimonial.jpeg"
                            alt="Mas M."
                            fill
                            className="object-cover"
                            onError={(e) => {
                              const target = e.target as HTMLImageElement
                              target.src = "/images/user-default.jpg"
                            }}
                          />
                        </div>
                        <div>
                          <h4 className="font-bold">Mas M.</h4>
                          <div className="flex">
                            {[...Array(5)].map((_, i) => (
                              <Star key={i} className="h-4 w-4 text-yellow-500 fill-yellow-500" />
                            ))}
                          </div>
                        </div>
                      </div>
                      <p className="text-muted-foreground">
                        "I've tried many programs before, but this 30-day transformation was different. The progressive
                        structure made it challenging but achievable, and I saw real results within the first two
                        weeks!"
                      </p>
                    </div>
                    <div className="border rounded-lg p-4">
                      <div className="flex items-center mb-3">
                        <div className="relative w-12 h-12 rounded-full overflow-hidden mr-3">
                          <Image
                            src="/images/mosa-testimonial.jpeg"
                            alt="Mosa R."
                            fill
                            className="object-cover"
                            onError={(e) => {
                              const target = e.target as HTMLImageElement
                              target.src = "/images/user-default.jpg"
                            }}
                          />
                        </div>
                        <div>
                          <h4 className="font-bold">Mosa R.</h4>
                          <div className="flex">
                            {[...Array(5)].map((_, i) => (
                              <Star key={i} className="h-4 w-4 text-yellow-500 fill-yellow-500" />
                            ))}
                          </div>
                        </div>
                      </div>
                      <p className="text-muted-foreground">
                        "As a busy professional, I needed something efficient and effective. This program delivered
                        exactly that. The nutrition guide was especially helpful in planning my meals around my hectic
                        schedule."
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
    </div>
  )
}

