"use client"

import { useState, useEffect, useRef } from "react"
import { useParams, useRouter } from "next/navigation"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Slider } from "@/components/ui/slider"
import { ProtectedRoute } from "@/components/protected-route"
import { upcomingWorkouts } from "@/data/workouts"
import { WorkoutTimer } from "@/components/workout-timer"
import { WorkoutCompletionModal } from "@/components/workout-completion-modal"
import { ArrowRight, CheckCircle, ChevronLeft, Pause, Play, Save, X } from "lucide-react"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"

export default function WorkoutSessionPage() {
  const params = useParams()
  const router = useRouter()
  const workoutId = params.id as string

  // Find the workout with the matching ID
  const workout = upcomingWorkouts.find((w) => w.id === workoutId)

  // State for tracking current exercise
  const [currentExerciseIndex, setCurrentExerciseIndex] = useState(0)
  const [completedSets, setCompletedSets] = useState<Record<string, boolean[]>>({})
  const [exerciseNotes, setExerciseNotes] = useState<Record<string, string>>({})
  const [weight, setWeight] = useState<Record<string, number>>({})

  // Timer state
  const [isTimerRunning, setIsTimerRunning] = useState(true)
  const [elapsedTime, setElapsedTime] = useState(0)
  const [isRestTimerActive, setIsRestTimerActive] = useState(false)
  const [restTimeRemaining, setRestTimeRemaining] = useState(0)

  // Modal states
  const [showCompletionModal, setShowCompletionModal] = useState(false)
  const [showExitConfirmation, setShowExitConfirmation] = useState(false)

  // Refs
  const restTimerRef = useRef<NodeJS.Timeout | null>(null)

  // If workout not found, redirect to dashboard
  if (!workout) {
    router.push("/dashboard")
    return null
  }

  const currentExercise = workout.exercises[currentExerciseIndex]

  // Initialize state for the current exercise if not already done
  useEffect(() => {
    if (currentExercise) {
      if (!completedSets[currentExercise.id]) {
        setCompletedSets((prev) => ({
          ...prev,
          [currentExercise.id]: Array(currentExercise.sets).fill(false),
        }))
      }

      if (currentExercise.weight !== undefined && !weight[currentExercise.id]) {
        setWeight((prev) => ({
          ...prev,
          [currentExercise.id]: currentExercise.weight || 0,
        }))
      }
    }
  }, [currentExercise, completedSets, weight])

  // Handle timer
  useEffect(() => {
    let interval: NodeJS.Timeout | null = null

    if (isTimerRunning && !isRestTimerActive) {
      interval = setInterval(() => {
        setElapsedTime((prev) => prev + 1)
      }, 1000)
    }

    return () => {
      if (interval) clearInterval(interval)
    }
  }, [isTimerRunning, isRestTimerActive])

  // Handle rest timer
  useEffect(() => {
    if (isRestTimerActive && restTimeRemaining > 0) {
      restTimerRef.current = setInterval(() => {
        setRestTimeRemaining((prev) => {
          if (prev <= 1) {
            clearInterval(restTimerRef.current as NodeJS.Timeout)
            setIsRestTimerActive(false)
            return 0
          }
          return prev - 1
        })
      }, 1000)
    }

    return () => {
      if (restTimerRef.current) clearInterval(restTimerRef.current)
    }
  }, [isRestTimerActive, restTimeRemaining])

  // Calculate progress
  const totalSets = workout.exercises.reduce((total, ex) => total + ex.sets, 0)
  const completedSetsCount = Object.values(completedSets).reduce(
    (total, sets) => total + sets.filter(Boolean).length,
    0,
  )
  const progress = totalSets > 0 ? (completedSetsCount / totalSets) * 100 : 0

  // Handle set completion
  const toggleSetCompletion = (setIndex: number) => {
    if (isRestTimerActive) return

    setCompletedSets((prev) => {
      const updatedSets = [...(prev[currentExercise.id] || [])]
      updatedSets[setIndex] = !updatedSets[setIndex]

      // If set was just completed and there's a rest time, start the rest timer
      if (updatedSets[setIndex] && currentExercise.restTime && setIndex < currentExercise.sets - 1) {
        setIsRestTimerActive(true)
        setRestTimeRemaining(currentExercise.restTime)
      }

      return {
        ...prev,
        [currentExercise.id]: updatedSets,
      }
    })
  }

  // Navigation between exercises
  const goToNextExercise = () => {
    if (currentExerciseIndex < workout.exercises.length - 1) {
      setCurrentExerciseIndex((prev) => prev + 1)
    } else {
      // All exercises completed
      setShowCompletionModal(true)
    }
  }

  const goToPreviousExercise = () => {
    if (currentExerciseIndex > 0) {
      setCurrentExerciseIndex((prev) => prev - 1)
    }
  }

  // Handle weight change
  const handleWeightChange = (value: number[]) => {
    setWeight((prev) => ({
      ...prev,
      [currentExercise.id]: value[0],
    }))
  }

  // Handle notes change
  const handleNotesChange = (exerciseId: string, note: string) => {
    setExerciseNotes((prev) => ({
      ...prev,
      [exerciseId]: note,
    }))
  }

  // Format time (seconds to MM:SS)
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`
  }

  // Handle workout completion
  const completeWorkout = () => {
    // Here you would typically save the workout data to a database
    // For now, we'll just redirect to the dashboard with a success message
    router.push("/dashboard?completed=true")
  }

  // Check if all sets of current exercise are completed
  const isCurrentExerciseCompleted = completedSets[currentExercise?.id]?.every(Boolean) || false

  // Handle exit workout
  const handleExitWorkout = () => {
    setShowExitConfirmation(true)
  }

  const confirmExit = () => {
    router.push("/dashboard")
  }

  return (
    <ProtectedRoute>
      <div className="flex min-h-screen flex-col bg-background">
        {/* Header */}
        <header className="sticky top-0 z-10 border-b bg-background">
          <div className="container flex h-16 items-center justify-between py-4">
            <div className="flex items-center gap-4">
              <Button
                variant="ghost"
                size="icon"
                onClick={handleExitWorkout}
                className="hover:bg-destructive/10 hover:text-destructive"
              >
                <X className="h-5 w-5" />
              </Button>
              <div>
                <h1 className="font-semibold">{workout.title}</h1>
                <p className="text-xs text-muted-foreground">In progress</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="ghost" size="sm" onClick={() => setIsTimerRunning(!isTimerRunning)} className="text-xs">
                {isTimerRunning ? (
                  <>
                    <Pause className="h-3 w-3 mr-1" /> Pause
                  </>
                ) : (
                  <>
                    <Play className="h-3 w-3 mr-1" /> Resume
                  </>
                )}
              </Button>
              <WorkoutTimer time={elapsedTime} isRunning={isTimerRunning} className="font-mono text-sm font-medium" />
            </div>
          </div>
        </header>

        {/* Progress bar */}
        <div className="bg-muted">
          <div className="container py-2">
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs font-medium">Workout Progress</span>
              <span className="text-xs">
                {completedSetsCount} / {totalSets} sets
              </span>
            </div>
            <Progress value={progress} className="h-2" />
          </div>
        </div>

        {/* Main content */}
        <main className="flex-1 container py-6">
          <div className="flex flex-col gap-6">
            {/* Exercise navigation */}
            <div className="flex items-center justify-between">
              <Button
                variant="ghost"
                onClick={goToPreviousExercise}
                disabled={currentExerciseIndex === 0}
                className="text-sm"
              >
                <ChevronLeft className="h-4 w-4 mr-1" />
                Previous
              </Button>
              <div className="text-center">
                <span className="text-sm font-medium">
                  Exercise {currentExerciseIndex + 1} of {workout.exercises.length}
                </span>
              </div>
              <Button variant="ghost" onClick={goToNextExercise} className="text-sm">
                Next
                <ArrowRight className="h-4 w-4 ml-1" />
              </Button>
            </div>

            {/* Current exercise */}
            <Card className="overflow-hidden">
              <div className="relative h-48 md:h-64 w-full">
                <Image
                  src={`/images/exercise-${currentExercise.name.toLowerCase().replace(/\s+/g, "-")}.jpg`}
                  alt={currentExercise.name}
                  fill
                  className="object-cover"
                  onError={(e) => {
                    const target = e.target as HTMLImageElement
                    target.src = "/images/exercise-default.jpg"
                  }}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-background to-transparent" />
                <div className="absolute bottom-4 left-4">
                  <Badge className="bg-primary mb-2">{currentExercise.category}</Badge>
                  <h2 className="text-2xl font-bold text-white drop-shadow-md">{currentExercise.name}</h2>
                </div>
              </div>
              <CardContent className="p-6">
                <div className="grid gap-6 md:grid-cols-2">
                  <div>
                    <h3 className="text-lg font-semibold mb-4">Instructions</h3>
                    <p className="text-muted-foreground mb-4">
                      {currentExercise.instructions ||
                        `Perform ${currentExercise.sets} sets of ${currentExercise.reps} reps with proper form. Focus on controlled movement and full range of motion.`}
                    </p>
                    {currentExercise.notes && (
                      <div className="mb-4">
                        <h4 className="font-medium mb-1">Notes:</h4>
                        <p className="text-sm text-muted-foreground">{currentExercise.notes}</p>
                      </div>
                    )}

                    {/* Weight adjustment (if applicable) */}
                    {currentExercise.weight !== undefined && (
                      <div className="mb-6">
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="font-medium">Weight:</h4>
                          <span className="font-mono">{weight[currentExercise.id] || currentExercise.weight} kg</span>
                        </div>
                        <Slider
                          defaultValue={[currentExercise.weight]}
                          min={0}
                          max={currentExercise.weight * 2}
                          step={2.5}
                          onValueChange={handleWeightChange}
                        />
                      </div>
                    )}

                    {/* Rest timer (if active) */}
                    {isRestTimerActive && (
                      <div className="bg-muted p-4 rounded-lg mb-4">
                        <h4 className="font-medium text-center mb-2">Rest Timer</h4>
                        <div className="text-3xl font-mono text-center mb-2">{formatTime(restTimeRemaining)}</div>
                        <Button variant="outline" className="w-full" onClick={() => setIsRestTimerActive(false)}>
                          Skip Rest
                        </Button>
                      </div>
                    )}
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-lg font-semibold">Sets</h3>
                      {isCurrentExerciseCompleted && (
                        <Badge variant="outline" className="text-green-500 border-green-500">
                          <CheckCircle className="h-3 w-3 mr-1" /> Completed
                        </Badge>
                      )}
                    </div>

                    <div className="space-y-3">
                      {Array.from({ length: currentExercise.sets }).map((_, index) => (
                        <div
                          key={index}
                          className={`flex items-center justify-between p-3 rounded-lg border ${
                            completedSets[currentExercise.id]?.[index] ? "bg-primary/10 border-primary" : "bg-muted/50"
                          } ${isRestTimerActive ? "opacity-50" : ""}`}
                          onClick={() => toggleSetCompletion(index)}
                        >
                          <div>
                            <span className="font-medium">Set {index + 1}</span>
                            <p className="text-sm text-muted-foreground">
                              {currentExercise.reps} reps
                              {weight[currentExercise.id] ? ` at ${weight[currentExercise.id]} kg` : ""}
                            </p>
                          </div>
                          <div
                            className={`h-6 w-6 rounded-full flex items-center justify-center ${
                              completedSets[currentExercise.id]?.[index]
                                ? "bg-primary text-primary-foreground"
                                : "bg-muted-foreground/20"
                            }`}
                          >
                            {completedSets[currentExercise.id]?.[index] && <CheckCircle className="h-4 w-4" />}
                          </div>
                        </div>
                      ))}
                    </div>

                    <div className="mt-6">
                      <Button
                        className="w-full"
                        disabled={!isCurrentExerciseCompleted || isRestTimerActive}
                        onClick={goToNextExercise}
                      >
                        {currentExerciseIndex < workout.exercises.length - 1 ? (
                          <>
                            Next Exercise <ArrowRight className="ml-2 h-4 w-4" />
                          </>
                        ) : (
                          <>
                            Complete Workout <CheckCircle className="ml-2 h-4 w-4" />
                          </>
                        )}
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Exercise list (collapsed view) */}
            <div className="mt-4">
              <h3 className="font-semibold mb-3">Workout Plan</h3>
              <div className="space-y-2">
                {workout.exercises.map((exercise, index) => {
                  const isCompleted = completedSets[exercise.id]?.every(Boolean) || false
                  const isCurrent = index === currentExerciseIndex

                  return (
                    <div
                      key={exercise.id}
                      className={`flex items-center p-3 rounded-lg border ${
                        isCurrent
                          ? "border-primary bg-primary/5"
                          : isCompleted
                            ? "bg-muted border-muted-foreground/20"
                            : "bg-background"
                      } cursor-pointer`}
                      onClick={() => setCurrentExerciseIndex(index)}
                    >
                      <div
                        className={`h-8 w-8 rounded-full flex items-center justify-center mr-3 ${
                          isCompleted
                            ? "bg-green-500 text-white"
                            : isCurrent
                              ? "bg-primary text-primary-foreground"
                              : "bg-muted-foreground/20"
                        }`}
                      >
                        {isCompleted ? <CheckCircle className="h-4 w-4" /> : <span>{index + 1}</span>}
                      </div>
                      <div className="flex-1">
                        <h4 className={`font-medium ${isCompleted ? "line-through opacity-70" : ""}`}>
                          {exercise.name}
                        </h4>
                        <p className="text-xs text-muted-foreground">
                          {exercise.sets} sets × {exercise.reps} reps
                          {exercise.weight ? ` at ${exercise.weight} kg` : ""}
                        </p>
                      </div>
                      {isCurrent && <Badge className="bg-primary">Current</Badge>}
                    </div>
                  )
                })}
              </div>
            </div>
          </div>
        </main>

        {/* Footer with actions */}
        <footer className="sticky bottom-0 border-t bg-background py-4">
          <div className="container flex justify-between">
            <Button
              variant="outline"
              size="sm"
              onClick={handleExitWorkout}
              className="text-destructive hover:bg-destructive/10 hover:text-destructive"
            >
              <X className="h-4 w-4 mr-1" /> Exit
            </Button>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={() => setIsTimerRunning(!isTimerRunning)}>
                {isTimerRunning ? (
                  <>
                    <Pause className="h-4 w-4 mr-1" /> Pause
                  </>
                ) : (
                  <>
                    <Play className="h-4 w-4 mr-1" /> Resume
                  </>
                )}
              </Button>
              <Button
                variant="default"
                size="sm"
                onClick={() => setShowCompletionModal(true)}
                disabled={progress < 100}
              >
                <Save className="h-4 w-4 mr-1" /> Finish
              </Button>
            </div>
          </div>
        </footer>

        {/* Workout Completion Modal */}
        <WorkoutCompletionModal
          isOpen={showCompletionModal}
          onClose={() => setShowCompletionModal(false)}
          onComplete={completeWorkout}
          workout={workout}
          elapsedTime={elapsedTime}
          completedSets={completedSets}
          totalSets={totalSets}
        />

        {/* Exit Confirmation Dialog */}
        <AlertDialog open={showExitConfirmation} onOpenChange={setShowExitConfirmation}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Exit Workout?</AlertDialogTitle>
              <AlertDialogDescription>
                Your workout progress will not be saved. Are you sure you want to exit?
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction
                onClick={confirmExit}
                className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              >
                Exit Workout
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </ProtectedRoute>
  )
}

